<?php
/*

Plugin Name: Eduhap Core

Plugin URI: http://getmasum.com

Description: After install the eduhap WordPress Theme, you must need to install this Plugin then will get all Features of eduhap WP Theme.

Author: Masum Billah

Author URI: http://www.getmasum.com

Version: 1.8

Text Domain: eduhap-core

*/


//define

define( 'EDUHAPCOREDIR', dirname( __FILE__ ) ); 

// Add main files

include_once(EDUHAPCOREDIR. '/inc/elementor-active.php');
include_once(EDUHAPCOREDIR. '/inc/custom_posts.php');
include_once(EDUHAPCOREDIR. '/inc/theme-options.php');
include_once(EDUHAPCOREDIR. '/inc/metabox.php');
include_once(EDUHAPCOREDIR. '/inc/widgets/footer_about.php');
include_once(EDUHAPCOREDIR. '/inc/widgets/footer_contact_info.php');


//Add Elementor Category
function eduhap_add_elementor_widget_categories( $elements_manager ) {

	$elements_manager->add_category(
		'eduhap-category',
		[
			'title' => esc_html__( 'Eduhap', 'eduhap' ),
		]
	);

}
add_action( 'elementor/elements/categories_registered', 'eduhap_add_elementor_widget_categories' );

