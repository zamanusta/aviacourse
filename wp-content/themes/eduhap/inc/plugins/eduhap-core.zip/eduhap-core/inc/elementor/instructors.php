<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapInstructorWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-instructors';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Instructor' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_instructors',
			[
				'label' => esc_html__( 'Instructors', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'number_posts',
			[
				'label' => esc_html__( 'Number of Post', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '5',
			]
		);	
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$number_posts = $this->get_settings_for_display( 'number_posts' );

		global $post, $authordata;
		
		?>
		
		<section class="team">
				<div class="container">

					<div class="row">
					
					<?php
					// WP_User_Query arguments
					$args = array(
						'role'           => 'tutor_instructor',
						'number'         => $number_posts,
						'order'          => 'ASC',
					);
					// The User Query
					$instructor_data    = get_users( $args );
					foreach ( $instructor_data as $instructor ) {
						
					$teacher_metadata = get_user_meta( $instructor->ID );
					$profile_url      = tutor_utils()->profile_url( $instructor->ID, true ); 
					$thumb            = isset( $teacher_metadata['_tutor_profile_photo'] ) ? wp_get_attachment_image( $teacher_metadata['_tutor_profile_photo'][0], 'full' ) : '';
					$name             = isset( $teacher_metadata['nickname'] ) ? '<h5><a href=' . $profile_url . '>' . $teacher_metadata['nickname'][0] . '</a></h5>' : '';
					$designation      = isset( $teacher_metadata['_tutor_profile_job_title'] ) ? '<p>' . $teacher_metadata['_tutor_profile_job_title'][0] . '</p>' : ''; '';
					$course_count      = tutor_utils()->get_course_count_by_instructor( $instructor->ID );
					$student_count     = tutor_utils()->get_total_students_by_instructor( $instructor->ID );
					$course_count_out  = sprintf( _n( '%s Course', '%s Courses', $course_count, 'edhub-core' ), $course_count );
					$student_count_out = sprintf( _n( '%s Student', '%s Students', $student_count, 'edhub-core' ), $student_count );
					$facebook   = get_user_meta($instructor->ID, '_tutor_profile_facebook',true ) ;
					$twitter   = get_user_meta($instructor->ID, '_tutor_profile_twitter',true ) ;
					$linkedin   = get_user_meta($instructor->ID, '_tutor_profile_linkedin',true ) ;
					$website   = get_user_meta($instructor->ID, '_tutor_profile_website',true ) ;
					$github   = get_user_meta($instructor->ID, '_tutor_profile_github',true ) ;

					?>

					<div class="col-xl-3 col-lg-4 col-sm-6">
						<div class="single-instructor">
							<?php echo $thumb; ?>
							
							<div class="ins-info">
							    <?php echo $name . $designation; ?>
								<div class="course-meta">
    								<span class="duration"><i class="far fa-user"></i><?php echo esc_attr( $student_count_out ); ?></span>
    								<span class="lessons"><i class="far fa-play-circle me-2"></i><?php echo esc_attr( $course_count_out ); ?></span>
    							</div>
    							<ul class="ins_social list-inline">			
    								<?php if($facebook){ ?>
    								<li class="list-inline-item"><a href="<?php echo esc_url($facebook);?>"> <i class="fab fa-facebook-f"></i></a></li>
    								<?php } if($twitter){ ?>
    								<li class="list-inline-item"><a href="<?php echo esc_url($twitter);?>"> <i class="fab fa-twitter"></i></a></li>
    								<?php } if($linkedin){ ?>
    								<li class="list-inline-item"><a href="<?php echo esc_url($linkedin);?>"> <i class="fab fa-linkedin-in"></i></a></li>
    								<?php } if($website){ ?>
    								<li class="list-inline-item"><a href="<?php echo esc_url($website);?>"> <i class="fas fa-globe"></i></a></li>
    								<?php } if($github){ ?>
    								<li class="list-inline-item"><a href="<?php echo esc_url($github);?>"> <i class="fab fa-github"></i></a></li>
    								<?php } ?>
    							</ul>
    
    						
						    </div>
						</div>
					</div>

					<?php
				} ?>
				
		
					</div>
				</div>
			</section>	
	
 	
		
<?php


	}

}
