<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapBlogWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-blog';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Blog' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_blog',
			[
				'label' => esc_html__( 'Blog', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

	
		$this->add_control(
			'blog_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => ' Blog News ',
			]
		);		
		
		$this->add_control(
			'blog_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Latest From The Blog',
			]
		);	
	
		$this->add_control(
			'blog_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'The ultimate planning solution for busy women who want to reach their personal goals',
			]
		);	
		

		$this->add_control(
			'number_posts',
			[
				'label' => esc_html__( 'Number of Posts', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '3',
			]
		);	
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$blog_subtitle = $this->get_settings_for_display( 'blog_subtitle' );
		$blog_title = $this->get_settings_for_display( 'blog_title' );
		$blog_content = $this->get_settings_for_display( 'blog_content' );
		$number_posts = $this->get_settings_for_display( 'number_posts' );

		?>
		

		<!-- Blog Section Start -->
		<section class="blog-section section-padding">
			<div class="container">
				<div class="row align-items-center justify-content-center">
					<div class="col-lg-7">
						<div class="section-heading center-heading">
							<span class="subheading"><?php echo eduhap_wp_kses($blog_subtitle);?></span>
							<h3><?php echo eduhap_wp_kses($blog_title);?></h3>
							<p><?php echo eduhap_wp_kses($blog_content);?></p>
						</div>
					</div>
				</div>

				<div class="row">  
					<?php
						// WP_Query arguments
						$args = array(
							'post_type'              => array( 'post' ),
							'posts_per_page'         => $number_posts,
						);

						// The Query
						$eduhap_blog_query = new WP_Query( $args );

						// The Loop
						if ( $eduhap_blog_query->have_posts() ) {
							while ( $eduhap_blog_query->have_posts() ) {
								$eduhap_blog_query->the_post();					
								
							?>
							
							<div class="col-lg-4 col-xl-4 col-md-6 ">
								<article class="blog-post-item">
									<?php if(has_post_thumbnail()){ ?>
										<div class="post-thumb">
											<?php the_post_thumbnail('eduhap_blog');?>
										</div>
									<?php } ?>	

									<div class="post-item mt-4">
										<div class="post-meta">
											<span class="post-author"><i class="fa fa-user me-2"></i> <?php eduhap_posted_by();?></span>
											<span class="post-date"><i class="fa fa-calendar-alt me-2"></i><?php echo get_the_time('M d, Y');?></span>
										</div>
										<h4 class="post-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
									</div>
								</article>
							</div>


							<?php
							}
						} else {
							// no posts found
						}

						// Restore original Post Data
						wp_reset_postdata();
					?>					

	
				</div>
			</div>
		</section>
		<!-- Blog Section End -->
		
<?php


	}

}
