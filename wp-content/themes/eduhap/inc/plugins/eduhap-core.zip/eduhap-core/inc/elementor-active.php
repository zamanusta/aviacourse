<?php

/**
 * Elementor Active
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Main Eduhap_Elementor_Active_Extension Class
 *
 * The main class that initiates and runs the plugin.
 *
 * @since 1.0.0
 */
final class Eduhap_Elementor_Active_Extension {

	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 *
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.0';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '5.6';

	/**
	 * Instance
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 * @static
	 *
	 * @var Eduhap_Elementor_Active_Extension The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 * @static
	 *
	 * @return Eduhap_Elementor_Active_Extension An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {


		add_action( 'plugins_loaded', [ $this, 'init' ] );

	}



	/**
	 * Initialize the plugin
	 *
	 * Load the plugin only after Elementor (and other plugins) are loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed load the files required to run the plugin.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init() {

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return;
		}

		// Add Plugin actions
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'eduhap' ),
			'<strong>' . esc_html__( 'Eduhap Plugin', 'eduhap' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'eduhap' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'eduhap' ),
			'<strong>' . esc_html__( 'Eduhap Plugin', 'eduhap' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'eduhap' ) . '</strong>',
			 self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'eduhap' ),
			'<strong>' . esc_html__( 'Eduhap Plugin', 'eduhap' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'eduhap' ) . '</strong>',
			 self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Init Widgets
	 *
	 * Include widgets files and register them
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init_widgets() {

		// Include Widget files

		require_once( __DIR__ . '/elementor/title.php' );
		require_once( __DIR__ . '/elementor/buttons.php' );
		require_once( __DIR__ . '/elementor/banner.php' );
		require_once( __DIR__ . '/elementor/banner-search.php' );
		require_once( __DIR__ . '/elementor/feature.php' );
		require_once( __DIR__ . '/elementor/about-video.php' );
		require_once( __DIR__ . '/elementor/about-content.php' );
		require_once( __DIR__ . '/elementor/counter-up.php' );
		require_once( __DIR__ . '/elementor/about-us.php' );
		require_once( __DIR__ . '/elementor/about-two.php' );
		require_once( __DIR__ . '/elementor/testimonials.php' );
		require_once( __DIR__ . '/elementor/team.php' );
		require_once( __DIR__ . '/elementor/instructors.php' );
		require_once( __DIR__ . '/elementor/call-to-action.php' );
		require_once( __DIR__ . '/elementor/newsletter.php' );
		require_once( __DIR__ . '/elementor/archive-courses.php' );		
		require_once( __DIR__ . '/elementor/courses.php' );
		require_once( __DIR__ . '/elementor/trending-course.php' );
		require_once( __DIR__ . '/elementor/category-title.php' );
		require_once( __DIR__ . '/elementor/category.php' );
		require_once( __DIR__ . '/elementor/clients.php' );
		require_once( __DIR__ . '/elementor/category-two.php' );
		require_once( __DIR__ . '/elementor/contact-info.php' );
		require_once( __DIR__ . '/elementor/contact-form.php' );
		require_once( __DIR__ . '/elementor/blog.php' );



		

		// Register widget

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapTitleWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapButtonsWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapBannerWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapBannerSearchWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapFeatureWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapAboutVideoWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapAboutContentWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapCounterUpWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapAboutUsWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapAboutTwoWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapTestimonialsWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapTeamWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapInstructorWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapCallToActionWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapNewsletterWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapArchiveCoursesWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapTrendingCourseWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapCoursesWidget() );		
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapCategoryTitleWidget()) ;	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapCategoryWidget()) ;	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapCategoryTwoWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapClientsUpWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapContactInfoWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapContactFormWidget() );	
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \EduhapBlogWidget() );	

	
	}



}

Eduhap_Elementor_Active_Extension::instance();