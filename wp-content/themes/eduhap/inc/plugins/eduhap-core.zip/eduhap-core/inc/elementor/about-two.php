<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapAboutTwoWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-about-two';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('About Two' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_about_two',
			[
				'label' => esc_html__( 'About Two', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Self Development Course',
			]
		);	
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Get Instant Access To Expert solution',
			]
		);	
		
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'The ultimate planning solution for busy women who want to reach their personal goals.Effortless comfortable eye-catching unique detail ',
			]
		);		
		
		$this->add_control(
			'sec_img',
			[
				'label' => esc_html__( 'Section Image', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
				
			]
		);		


		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'ab_title', [
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);			
		
		$repeater->add_control(
			'ab_icon', [
				'label' => esc_html__( 'Number', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		
		$repeater->add_control(
			'ab_content', [
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);		
		

		$this->add_control(
			'about_list',
			[
				'label' => esc_html__
				( 'About List', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																															
						'ab_title' => 'Sign up in website',							
						'ab_icon' => 'flaticon-video-camera',																																																																																																			
						'ab_content' => 'The right mentoring relationship can be a powerful tool for professional growth. Bark up the right tree.',																																																																																																			
																																																										
					],
		
				],

			]
		);		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		$sec_img = $this->get_settings_for_display( 'sec_img' )['url'];
		$about_list = $this->get_settings_for_display( 'about_list' );
		
		?>
		
		<section class="about section-padding">
			<div class="container">
				<div class="row align-items-center justify-content-center">
					<div class="col-xl-6 col-lg-6">
						<div class="section-heading ">
							<span class="subheading"><?php echo eduhap_wp_kses($sec_subtitle);?></span>
							<h3><?php echo eduhap_wp_kses($sec_title);?></h3>
							<p><?php echo eduhap_wp_kses($sec_content);?></p>
						</div>

					<?php
						foreach ($about_list as $item ) { ?>	
							<div class="about-text-block">
								<div class="icon-box">
									<i class="<?php echo esc_attr($item['ab_icon']);?>"></i>
								</div>
								<div class="about-desc">
									<h4><?php echo eduhap_wp_kses($item['ab_title']);?></h4>
									<p><?php echo eduhap_wp_kses($item['ab_content']);?></p>
								</div>
							</div>			
							
							
					<?php } ?>


					</div>

					<div class="col-xl-6 col-lg-6">
						<div class="about-img">
							<img src="<?php echo esc_url($sec_img);?>" alt="" class="img-fluid">
						</div>
					</div>
				</div>
			</div>
		</section>
		
<?php

	}

}
