<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapContactFormWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-contact-form';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Contact Form' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_contact_form',
			[
				'label' => esc_html__( 'Contact Form', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'contact_form',
			[
				'label' => esc_html__( 'Form Shortcode', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,

			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$contact_form = $this->get_settings_for_display( 'contact_form' );
		
		?>

		<div class="contact__form form-row" id="contactForm">
			<?php echo do_shortcode($contact_form);?>
	   </div>

<?php

	}

}
