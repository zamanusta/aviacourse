<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapTrendingCourseWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-trending-course';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Trending Course' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_trending_course',
			[
				'label' => esc_html__( 'Trending Course', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

	
		$this->add_control(
			'se_style',
			[
				'label' => esc_html__( 'Style', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'default' => '1',
				'options' => [
					'1' => esc_html__( '1', 'eduhap' ),
					'2'  => esc_html__( '2', 'eduhap' ),
				],
			]
		);		
		
		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => ' Trending Courses ',
			]
		);		
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Over 200+ Online Courses ',
			]
		);	
	
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'The ultimate planning solution for busy women who want to reach their personal goals',
			]
		);	
		
		$this->add_control(
			'sec_tbtn_text',
			[
				'label' => esc_html__( 'Title Button Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'All courses',
			]
		);		
		
		$this->add_control(
			'sec_tbtn_link',
			[
				'label' => esc_html__( 'Title Button Link', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);
		
		$this->add_control(
			'number_posts',
			[
				'label' => esc_html__( 'Number of Posts', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '3',
			]
		);
		
		
		$this->add_control(
			'btn_content',
			[
				'label' => esc_html__( 'Button Large Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Take the control of their life back and start doing things to make their dream come true.',
			]
		);			
		
		$this->add_control(
			'btn_text',
			[
				'label' => esc_html__( 'Button Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'View all courses ',
			]
		);		
		
		$this->add_control(
			'btn_link',
			[
				'label' => esc_html__( 'Button Link', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);	
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$se_style = $this->get_settings_for_display( 'se_style' );
		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		$sec_tbtn_text = $this->get_settings_for_display( 'sec_tbtn_text' );
		$sec_tbtn_link = $this->get_settings_for_display( 'sec_tbtn_link' );
		$number_posts = $this->get_settings_for_display( 'number_posts' );
		$btn_content = $this->get_settings_for_display( 'btn_content' );
		$btn_text = $this->get_settings_for_display( 'btn_text' );
		$btn_link = $this->get_settings_for_display( 'btn_link' );
		
		global $post, $authordata;
		
		if($se_style == '2'){ ?>
			<section class="section-padding popular-course-list">
				<div class="container">
					<div class="row align-items-center justify-content-center">
						<div class="col-lg-8 col-xl-8 col-md-8">
							<div class="section-heading <?php if($sec_tbtn_link){ echo esc_attr(' mb-sm-0');}else{ echo esc_attr('text-center');}?>">
								<span class="subheading"><?php echo esc_html($sec_subtitle);?></span>
								<h3><?php echo eduhap_wp_kses($sec_title);?></h3>
								<p><?php echo eduhap_wp_kses($sec_content);?></p>
							</div>
						</div>
						<?php if($sec_tbtn_link){ ?>
						<div class="col-xl-4 col-lg-4  col-md-4">
							<div class="text-md-right mb-5 mb-md-0">
								<a href="<?php echo esc_url($sec_tbtn_link);?>" class="btn btn-main"><?php echo esc_html($sec_tbtn_text);?></a>
							</div>
						</div>
						<?php } ?>
					</div>

					<div class="row">
					<?php
						// WP_Query arguments
						$args = array(
							'post_type'              => array( 'courses' ),
							'posts_per_page'         => $number_posts,
						);

						// The Query
						$eduhap_trending_course_query = new WP_Query( $args );

						// The Loop
						if ( $eduhap_trending_course_query->have_posts() ) {
							while ( $eduhap_trending_course_query->have_posts() ) {
								$eduhap_trending_course_query->the_post();			
								$course_id         = get_the_ID();
								$profile_url       = tutor_utils()->profile_url( $authordata->ID, true );
							?>
						
							<div class="col-lg-6 col-md-12">
								<div class="course-block course-list-item">
									<div class="row align-items-center">
										<div class="col-lg-4 col-sm-4 ">
											<div class="course-img mb-4 mb-md-0">
												<?php the_post_thumbnail('eduhap_course_two');?>
											</div>
										</div>
										<div class="col-lg-8  col-sm-8">
											<div class="course-content">
												<div class="course-price ">
													<?php
														$price = tutor_utils()->get_course_price();
													if ( null === $price ) {
														esc_html_e( 'Free', 'eduhap' );
													} else {
														echo wp_kses_post( tutor_utils()->get_course_price() );
													}
													?>
												</div>   
												<h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>    
												<div class="course-meta">
													<span class="course-author"><?php echo esc_html__('By' , 'eduhap');?> <a href="<?php echo esc_url( $profile_url ); ?>"><?php echo esc_html( get_the_author() ); ?></a></span>
													<span class="course-duration"><i class="far fa-file-alt"></i> <?php echo esc_html( tutor_utils()->get_lesson_count_by_course( $course_id ) ) ?> <?php echo esc_html__('Lessons' , 'eduhap');?></span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<?php
							}
						} else {
							// no posts found
						}

						// Restore original Post Data
						wp_reset_postdata();
					?>							


					</div>

					<div class="row justify-content-center">
						<div class="col-xl-6">
							<div class="text-center mt-5">
								<p><?php echo eduhap_wp_kses($btn_content);?></p> <a href="<?php echo esc_url($btn_link);?>" class="font-weight-bold text-underline"><?php echo esc_html($btn_text);?> </a>
							</div>
						</div>
					</div>
				</div>
			</section>			
		<?php }else{ ?>
			<section class="section-padding popular-course bg-grey">
				<div class="container">
					<div class="row align-items-center justify-content-center">
						<div class="col-lg-7">
							<div class="section-heading center-heading">
								<span class="subheading"><?php echo esc_html($sec_subtitle);?></span>
								<h3><?php echo eduhap_wp_kses($sec_title);?></h3>
								<p><?php echo eduhap_wp_kses($sec_content);?></p>
							</div>
						</div>
					</div>

					<div class="row">
				<?php
						// WP_Query arguments
						$args = array(
							'post_type'              => array( 'courses' ),
							'posts_per_page'         => $number_posts,
						);

						// The Query
						$eduhap_trending_course_query = new WP_Query( $args );

						// The Loop
						if ( $eduhap_trending_course_query->have_posts() ) {
							while ( $eduhap_trending_course_query->have_posts() ) {
								$eduhap_trending_course_query->the_post();					
								$course_id         = get_the_ID();
								$course_students   = apply_filters( 'tutor_course_students', tutor_utils()->count_enrolled_users_by_course( $course_id ), $course_id );

								$course_categories = get_tutor_course_categories( $course_id );								
							?>
						
							<div class="col-lg-4 col-md-6">
								<div class="course-block">
									<div class="course-img">
										<?php the_post_thumbnail('eduhap_course');?>
										<div class="course-price ">
											<?php
												$price = tutor_utils()->get_course_price();
											if ( null === $price ) {
												esc_html_e( 'Free', 'eduhap' );
											} else {
												echo wp_kses_post( tutor_utils()->get_course_price() );
											}
											?>
										</div>     
									</div>
									
									<div class="course-content">
										<span class="course-cat"> 
											<?php
											$category_links = array();
											foreach ( $course_categories as $course_category ) :
												$category_name    = $course_category->name;
												$category_link    = get_term_link( $course_category->term_id );
												$category_links[] = wp_sprintf( '<a href="%1$s">%2$s</a>', esc_url( $category_link ), esc_html( $category_name ) );
												endforeach;
												echo wp_kses(
													implode( ', ', $category_links ),
													array( 'a' => array( 'href' => true ) )
												);
											?>			
										</span>
										<div class="course_rating mb-10">
											<?php
								$course_rating = tutor_utils()->get_course_rating( $course_id );
								tutor_utils()->star_rating_generator( $course_rating->rating_avg ); ?>

											<span><?php echo $course_rating->rating_avg;?> (<?php esc_html_e( $course_rating->rating_count ); ?> <?php esc_html_e('reviews' , 'eduhap');?>)</span>
										</div>
										
										<h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>   
										<div class="course-meta">
											<span class="course-student"><i class="fa fa-user-alt"></i><?php echo esc_html( $course_students ); ?> <?php echo esc_html__('Students' , 'eduhap');?></span>
											<span class="course-duration"><i class="far fa-file-alt"></i> <?php echo esc_html( tutor_utils()->get_lesson_count_by_course( $course_id ) ) ?> <?php echo esc_html__('Lessons' , 'eduhap');?></span>
										</div> 
									</div>
								</div>
							</div>

							<?php
							}
						} else {
							// no posts found
						}

						// Restore original Post Data
						wp_reset_postdata();
					?>						


					</div>

					<div class="row justify-content-center">
						<div class="col-xl-6">
							<div class="text-center mt-5">
								<p><?php echo eduhap_wp_kses($btn_content);?></p> 
								<a href="<?php echo esc_url($btn_link);?>" class="font-weight-bold text-underline"><?php echo esc_html($btn_text);?> </a>
							</div>
						</div>
					</div>
				</div>
			</section>			
		<?php } ?>



<?php


	}

}
