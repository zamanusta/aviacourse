<?php


add_action( 'cmb2_init', 'eduhap_metabox_options' );

function eduhap_metabox_options(){
	// Start with an underscore to hide fields from custom fields list
	$prefix = '_eduhap_';

	// Page Options	
	$cmb2_post_page_opt = new_cmb2_box( array(
		'id'           => $prefix . 'page_option',
		'title'        => esc_html__( 'Options', 'eduhap' ),
		'object_types' => array(  'page' , 'post', 'product', 'courses'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );
	

	$cmb2_post_page_opt->add_field( array(
	    'name'             => esc_html__('Header Style' , 'eduhap'),
	    'id'               => $prefix .'header_style',
		'desc'    => esc_html__('Select here' , 'eduhap'),
	    'type'    => 'select',
		'default'          => '1',
		'options'          => array(
			'1' => esc_html__( 'One', 'eduhap' ),
			'2' => esc_html__( 'Two', 'eduhap' ),
			'3' => esc_html__( 'Three', 'eduhap' ),
			'4' => esc_html__( 'Four', 'eduhap' ),
		),		
	) );	
	
	$cmb2_post_page_opt->add_field( array(
	    'name'             => esc_html__('Footer Style' , 'eduhap'),
	    'id'               => $prefix .'footer_style',
		'desc'    => esc_html__('Select here' , 'eduhap'),
	    'type'    => 'select',
		'default'          => '1',
		'options'          => array(
			'1' => esc_html__( 'One', 'eduhap' ),
			'2' => esc_html__( 'Two', 'eduhap' ),
		),		
	) );	

	$cmb2_post_page_opt->add_field( array(
	    'name'             => esc_html__('Footer Top Padding' , 'eduhap'),
	    'id'               => $prefix .'footer_top_padding',
		'desc'    => esc_html__('Select here' , 'eduhap'),
	    'type'    => 'select',
		'default'          => '2',
		'options'          => array(
			'1' => esc_html__( 'Yes', 'eduhap' ),
			'2' => esc_html__( 'No', 'eduhap' ),
		),		
	) );
	$cmb2_post_page_opt->add_field( array(
	    'name'             => esc_html__('Hide Banner ' , 'eduhap'),
	    'id'               => $prefix .'hide_banner',
		'desc'    => esc_html__('Check/Uncheck here' , 'eduhap'),
	    'type'    => 'checkbox',
	) );

	
	if (class_exists('RevSlider')) {
		global $wpdb;
		$rs_table_name = $wpdb->prefix . "revslider_sliders";
		$rs = $wpdb->get_results( "SELECT id, title, alias FROM $rs_table_name ORDER BY id ASC LIMIT 999" );
		$revsliders = array();
		if ($rs) {
			foreach ( $rs as $slider ) {
				$revsliders[$slider->alias] = $slider->alias;
			}
		} else {
			$revsliders["No sliders found"] = 'No Alias found';
		}
		$cmb2_post_page_opt->add_field( array(
		    'name'             =>  esc_html__('Rev Slider Alias','eduhap' ), 
		    'id'               => $prefix.'rev_slider_alias',
		    'type'             => 'select',
		    'options'          => $revsliders,
		    'default'          => '',
		    'desc'         	   => esc_html__( 'Select any One, Which One You want to display','eduhap' ),
			'show_option_none' => true,
		) );
		
	
	}

	
	//Start Testimonials Options
	$eduhap_testimonial = new_cmb2_box( array(
		'id'           => $prefix . 'testimonials_options',
		'title'        => esc_html__( 'Testimonials Info', 'eduhap' ),
		'object_types' => array( 'testimonials'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );
	
	$eduhap_testimonial->add_field( array(
	    'name'             => esc_html__('Designation' , 'eduhap'),
	    'id'               => $prefix .'test_designation',
		'desc'    => esc_html__('wirte text here' , 'eduhap'),
	    'type'    => 'text',
		'default'    => 'Jessica Smith - Amazon co.',
				
	) );	
	
	//Start Team Options
	$eduhap_team = new_cmb2_box( array(
		'id'           => $prefix . 'team_options',
		'title'        => esc_html__( 'Team Info', 'eduhap' ),
		'object_types' => array( 'team'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );
	
	$eduhap_team->add_field( array(
	    'name'             => esc_html__('Designation' , 'eduhap'),
	    'id'               => $prefix .'team_designation',
		'desc'    => esc_html__('wirte text here' , 'eduhap'),
	    'type'    => 'text',
		'default'    => 'Jessica Smith - Amazon co.',
				
	) );	

	$team_group_field_id = $eduhap_team->add_field( array(
		'id'          => $prefix .'team_group_field_opt',
		'type'        => 'group',
		// 'repeatable'  => false, // use false if you want non-repeatable group
		'options'     => array(
			'group_title'   => esc_html__( 'Social  {#}', 'eduhap' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'    => esc_html__( 'Add New Social', 'eduhap' ),
			'remove_button' => esc_html__( 'Remove Social', 'eduhap' ),
			'sortable'      => true, // beta
			// 'closed'     => true, // true to have the groups closed by default
		),
	) );

	// Id's for group's fields only need to be unique for the group. Prefix is not needed.
	$eduhap_team->add_group_field( $team_group_field_id, array(
		'name' => esc_html__('Social Icon' , 'eduhap'),
		'id'   => $prefix .'team_social_icon',
		'type' => 'text',
		'default' => 'fab fa-facebook-f',
		'description' => esc_html__('write icon here' , 'eduhap'),
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );
	
	// Id's for group's fields only need to be unique for the group. Prefix is not needed.
	$eduhap_team->add_group_field( $team_group_field_id, array(
		'name'             => esc_html__('Social Link' , 'eduhap'),
		'id'               => $prefix .'team_social_link',
		'type' => 'text',
		'default' => '#',
		'desc'             => esc_html__( 'enter url here','eduhap' ),
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );		
}