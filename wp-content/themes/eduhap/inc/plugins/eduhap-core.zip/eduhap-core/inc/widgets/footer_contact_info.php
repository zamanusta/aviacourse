<?php

class eduhap_footer_contact_info_Widget extends WP_Widget {
 
    function __construct() {
 
        parent::__construct(
            'eduhap-footer-contact-info',  // Base ID
            'Eduhap: Footer Contact Info'   // Name
        );
 
        add_action( 'widgets_init', function() {
            register_widget( 'eduhap_footer_contact_info_Widget' );
        });
 
    }
 
    
 
    public function widget( $args, $instance ) {
 
        echo $args['before_widget'];
 
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
		
		$phone_label = $instance['phone_label'];
		$phone_number = $instance['phone_number'];
		$email_label = $instance['email_label'];
		$email_address = $instance['email_address'];
		$loc_label = $instance['loc_label'];
		$location = $instance['location'];
		$follow_us = $instance['follow_us'];
		$fsiname = $instance['fsiname'];
		$fslink = $instance['fslink'];
		$ssiname = $instance['ssiname'];
		$sslink = $instance['sslink'];
		$tsiname = $instance['tsiname'];
		$tslink = $instance['tslink'];
		$fosiname = $instance['fosiname'];
		$foslink = $instance['foslink'];
		
	?>

		<ul class="list-unstyled footer-info">
			<li><span><?php echo esc_html($phone_label);?></span><?php echo eduhap_wp_kses($phone_number);?></li>
			<li><span><?php echo esc_html($email_label);?></span><?php echo eduhap_wp_kses($email_address);?></li>
			<li><span><?php echo esc_html($loc_label);?></span><?php echo eduhap_wp_kses($location);?></li>
		</ul>

		<ul class="list-inline footer-socials">
			<li class="list-inline-item"><?php echo esc_html($follow_us);?></li>
			<?php if($fslink){ ?>
			<li class="list-inline-item">
				<a href="<?php echo esc_url($fslink);?>">
					<i class="<?php echo esc_attr($fsiname);?>"></i>
				</a>
			</li>
			<?php } if($sslink){ ?>
			<li class="list-inline-item">
				<a href="<?php echo esc_url($sslink);?>">
					<i class="<?php echo esc_attr($ssiname);?>"></i>
				</a>
			</li>
			<?php } if($tslink){ ?>
			<li class="list-inline-item">
				<a href="<?php echo esc_url($tslink);?>">
					<i class="<?php echo esc_attr($tsiname);?>"></i>
				</a>
			</li>
			<?php } if($foslink){ ?>
			<li class="list-inline-item">
				<a href="<?php echo esc_url($foslink);?>">
					<i class="<?php echo esc_attr($fosiname);?>"></i>
				</a>
			</li>
			<?php } ?>
		</ul>
	 
	<?php
	
	echo $args['after_widget'];
    }
 
    public function form( $instance ) {
 
        $title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'eduhap' );
		$phone_label = ! empty( $instance['phone_label'] ) ? $instance['phone_label'] : esc_html__( 'Ph:', 'eduhap' );
		$phone_number = ! empty( $instance['phone_number'] ) ? $instance['phone_number'] : esc_html__( '', 'eduhap' );
		$email_label = ! empty( $instance['email_label'] ) ? $instance['email_label'] : esc_html__( 'Email:', 'eduhap' );
		$email_address = ! empty( $instance['email_address'] ) ? $instance['email_address'] : esc_html__( '', 'eduhap' );
		$loc_label = ! empty( $instance['loc_label'] ) ? $instance['loc_label'] : esc_html__( 'Location:', 'eduhap' );
		$location = ! empty( $instance['location'] ) ? $instance['location'] : esc_html__( '', 'eduhap' );
		$follow_us = ! empty( $instance['follow_us'] ) ? $instance['follow_us'] : esc_html__( 'Follow Us:', 'eduhap' );
		$fsiname = ! empty( $instance['fsiname'] ) ? $instance['fsiname'] : esc_html__( '', 'eduhap' );
        $fslink = ! empty( $instance['fslink'] ) ? $instance['fslink'] : esc_html__( '', 'eduhap' );
        $ssiname = ! empty( $instance['ssiname'] ) ? $instance['ssiname'] : esc_html__( '', 'eduhap' );
        $sslink = ! empty( $instance['sslink'] ) ? $instance['sslink'] : esc_html__( '', 'eduhap' );
        $tsiname = ! empty( $instance['tsiname'] ) ? $instance['tsiname'] : esc_html__( '', 'eduhap' );
        $tslink = ! empty( $instance['tslink'] ) ? $instance['tslink'] : esc_html__( '', 'eduhap' );
        $fosiname = ! empty( $instance['fosiname'] ) ? $instance['fosiname'] : esc_html__( '', 'eduhap' );
        $foslink = ! empty( $instance['foslink'] ) ? $instance['foslink'] : esc_html__( '', 'eduhap' );
        
		?>
		
        <p>
        <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>

		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'phone_label' ) ); ?>"><?php echo esc_html__( 'Phone Label:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'phone_label' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'phone_label' ) ); ?>" type="text" value="<?php echo esc_attr( $phone_label ); ?>">
        </p>
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'phone_number' ) ); ?>"><?php echo esc_html__( 'Phone Number:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'phone_number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'phone_number' ) ); ?>" type="text" value="<?php echo esc_attr( $phone_number ); ?>">
        </p>		
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'email_label' ) ); ?>"><?php echo esc_html__( 'Eamil Label:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'email_label' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'email_label' ) ); ?>" type="text" value="<?php echo esc_attr( $email_label ); ?>">
        </p>	
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'email_address' ) ); ?>"><?php echo esc_html__( 'Email Address:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'email_address' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'email_address' ) ); ?>" type="text" value="<?php echo esc_attr( $email_address ); ?>">
        </p>	

		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'loc_label' ) ); ?>"><?php echo esc_html__( 'Location Label:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'loc_label' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'loc_label' ) ); ?>" type="text" value="<?php echo esc_attr( $loc_label ); ?>">
        </p>	
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'location' ) ); ?>"><?php echo esc_html__( 'Location:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'location' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'location' ) ); ?>" type="text" value="<?php echo esc_attr( $location ); ?>">
        </p>		
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'follow_us' ) ); ?>"><?php echo esc_html__( 'Follow Us:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'follow_us' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'follow_us' ) ); ?>" type="text" value="<?php echo esc_attr( $follow_us ); ?>">
        </p>
		

		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'fsiname' ) ); ?>"><?php echo esc_html__( 'First Social Icon Name:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'fsiname' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'fsiname' ) ); ?>" type="text" value="<?php echo esc_attr( $fsiname ); ?>">
        </p>
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'fslink' ) ); ?>"><?php echo esc_html__( 'First Social Link:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'fslink' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'fslink' ) ); ?>" type="text" value="<?php echo esc_attr( $fslink ); ?>">
        </p>
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'ssiname' ) ); ?>"><?php echo esc_html__( 'Second Social Icon Name:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'ssiname' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'ssiname' ) ); ?>" type="text" value="<?php echo esc_attr( $ssiname ); ?>">
        </p>
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'sslink' ) ); ?>"><?php echo esc_html__( 'Second Social Link:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'sslink' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'sslink' ) ); ?>" type="text" value="<?php echo esc_attr( $sslink ); ?>">
        </p>		
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'tsiname' ) ); ?>"><?php echo esc_html__( 'Third Social Icon Name:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'tsiname' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tsiname' ) ); ?>" type="text" value="<?php echo esc_attr( $tsiname ); ?>">
        </p>
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'tslink' ) ); ?>"><?php echo esc_html__( 'Third Social Link:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'tslink' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tslink' ) ); ?>" type="text" value="<?php echo esc_attr( $tslink ); ?>">
        </p>		
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'fosiname' ) ); ?>"><?php echo esc_html__( 'Fourth Social Icon Name:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'fosiname' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'fosiname' ) ); ?>" type="text" value="<?php echo esc_attr( $fosiname ); ?>">
        </p>
		
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'foslink' ) ); ?>"><?php echo esc_html__( 'Fourth Social Link:', 'eduhap' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'foslink' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'foslink' ) ); ?>" type="text" value="<?php echo esc_attr( $foslink ); ?>">
        </p>
		
        <?php
 
    }
 
    public function update( $new_instance, $old_instance ) {
 
        $instance = array();
 
        $instance['title'] = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['phone_label'] = ( !empty( $new_instance['phone_label'] ) ) ? $new_instance['phone_label'] : '';
        $instance['phone_number'] = ( !empty( $new_instance['phone_number'] ) ) ? $new_instance['phone_number'] : '';
        $instance['email_label'] = ( !empty( $new_instance['email_label'] ) ) ? $new_instance['email_label'] : '';
        $instance['email_address'] = ( !empty( $new_instance['email_address'] ) ) ? $new_instance['email_address'] : '';
        $instance['loc_label'] = ( !empty( $new_instance['loc_label'] ) ) ? $new_instance['loc_label'] : '';
        $instance['location'] = ( !empty( $new_instance['location'] ) ) ? $new_instance['location'] : '';
        $instance['follow_us'] = ( !empty( $new_instance['follow_us'] ) ) ? $new_instance['follow_us'] : '';
        $instance['fsiname'] = ( !empty( $new_instance['fsiname'] ) ) ? $new_instance['fsiname'] : '';
        $instance['fslink'] = ( !empty( $new_instance['fslink'] ) ) ? $new_instance['fslink'] : '';
        $instance['ssiname'] = ( !empty( $new_instance['ssiname'] ) ) ? $new_instance['ssiname'] : '';
        $instance['sslink'] = ( !empty( $new_instance['sslink'] ) ) ? $new_instance['sslink'] : '';
        $instance['tsiname'] = ( !empty( $new_instance['tsiname'] ) ) ? $new_instance['tsiname'] : '';
        $instance['tslink'] = ( !empty( $new_instance['tslink'] ) ) ? $new_instance['tslink'] : '';
        $instance['fosiname'] = ( !empty( $new_instance['fosiname'] ) ) ? $new_instance['fosiname'] : '';
        $instance['foslink'] = ( !empty( $new_instance['foslink'] ) ) ? $new_instance['foslink'] : '';
 
        return $instance;
    }
 
}

$eduhap_footer_contact_info = new eduhap_footer_contact_info_Widget();

?>