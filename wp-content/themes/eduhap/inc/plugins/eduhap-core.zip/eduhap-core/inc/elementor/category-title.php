<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapCategoryTitleWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-category-title';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Category Title' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Explore category',
			]
		);	
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Get Instant Access To Expert solution',
			]
		);	
		
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'The ultimate planning solution for
				busy women who want to reach their personal goals',
			]
		);			
		
		$this->add_control(
			'sec_btn_text',
			[
				'label' => esc_html__( 'Button Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Explore Category',
			]
		);	
		
		$this->add_control(
			'sec_btn_link',
			[
				'label' => esc_html__( 'Button Link', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		$sec_btn_text = $this->get_settings_for_display( 'sec_btn_text' );
		$sec_btn_link = $this->get_settings_for_display( 'sec_btn_link' );
		
		?>

	<div class="section-heading ps-5">
		<span class="subheading"><?php echo esc_html($sec_subtitle );?></span>
		<h3><?php echo eduhap_wp_kses($sec_title );?></h3>
		<p class="mb-4"><?php echo eduhap_wp_kses($sec_content );?></p>
		<?php if($sec_btn_link){ ?>
		<a href="<?php echo esc_url($sec_btn_link);?>" class="btn btn-main"><?php echo esc_html($sec_btn_text);?></a>
		<?php } ?>
	</div>

<?php

	}

}
