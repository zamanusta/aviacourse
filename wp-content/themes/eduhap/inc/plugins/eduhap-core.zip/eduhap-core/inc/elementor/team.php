<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapTeamWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-team';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Team' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_team',
			[
				'label' => esc_html__( 'Team', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Best Expert Team',
			]
		);	
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Our Professional Team',
			]
		);	
		
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'The ultimate planning solution for
				busy women who want to reach their personal goals',
			]
		);		
		
		$this->add_control(
			'sec_num',
			[
				'label' => esc_html__( 'Number of Posts', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '4',
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		$sec_num = $this->get_settings_for_display( 'sec_num' );
		
		?>

	<!-- Team section start -->
	<section class="team">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-7 col-xl-7">
					<div class="section-heading center-heading">
						<span class="subheading"><?php echo eduhap_wp_kses($sec_subtitle);?></span>
						<h3><?php echo eduhap_wp_kses($sec_title);?></h3>
						<p><?php echo eduhap_wp_kses($sec_content);?></p>
					</div>
				</div>
			</div>


			<div class="row">
				<?php
				// WP_Query arguments
				$args = array(
					'post_type'              => array( 'team' ),
					'posts_per_page'         => $sec_num,
				);

				// The Query
				$eduhap_team_query = new WP_Query( $args );

				// The Loop
				if ( $eduhap_team_query->have_posts() ) {
					while ( $eduhap_team_query->have_posts() ) {
						$eduhap_team_query->the_post();
						$eduhap_team_designation = get_post_meta(get_the_ID(),'_eduhap_team_designation', true);
						$eduhap_team_group_field_opt = get_post_meta(get_the_ID(),'_eduhap_team_group_field_opt', true);
						?>
						
						<div class="col-lg-3 col-md-6 col-sm-6">
							<div class="team-item">
								<?php the_post_thumbnail('eduhap_team');?>
								<div class="team-info">
									<h5><?php the_title();?></h5>
									<p><?php echo esc_html($eduhap_team_designation);?></p>
									<ul class="team-socials list-inline">
										<?php
											foreach ( (array) $eduhap_team_group_field_opt as $key => $team_entry ) {

											$icon = $link = '';

											if ( isset( $team_entry['_eduhap_team_social_icon'] ) )
												$icon = $team_entry['_eduhap_team_social_icon'];	

											if ( isset( $team_entry['_eduhap_team_social_link'] ) )
												$link = $team_entry['_eduhap_team_social_link'];	

											?>
												
											<li class="list-inline-item"><a href="<?php echo esc_url($link);?>"><i class="<?php echo esc_attr($icon);?>"></i></a></li>
											
										<?php } ?>									

									</ul>
								</div>
							</div>
						</div>						
					
					<?php	
					}
				} else {
					// no posts found
				}

				// Restore original Post Data
				wp_reset_postdata();
				?>

				
			</div>
		</div>
	</section>
	<!-- Team section End -->

<?php

	}

}
