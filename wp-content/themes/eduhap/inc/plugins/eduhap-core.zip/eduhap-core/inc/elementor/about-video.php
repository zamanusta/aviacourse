<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapAboutVideoWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-about-video';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('About Video' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_about_video',
			[
				'label' => esc_html__( 'About Video', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'sec_bg_img',
			[
				'label' => esc_html__( 'Background Image', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);	
		
		$this->add_control(
			'video_url',
			[
				'label' => esc_html__( 'Video Url', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '',
			]
		);	

		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_bg_img = $this->get_settings_for_display( 'sec_bg_img' )['url'];
		$video_url = $this->get_settings_for_display( 'video_url' );
		
		?>

			<div class="video-block">
				<img src="<?php echo esc_url($sec_bg_img);?>" alt="" class="img-fluid">
				<a href="<?php echo esc_url($video_url);?>" class="video-icon"><i class="fa fa-play"></i></a>
			</div>

<?php

	}

}
