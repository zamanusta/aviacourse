<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapBannerWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-banner';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Banner' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_banner',
			[
				'label' => esc_html__( 'Banner', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_style',
			[
				'label' => esc_html__( 'Style', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( '1', 'eduhap' ),
					'2' => esc_html__( '2', 'eduhap' ),
					'3' => esc_html__( '3', 'eduhap' ),

				],
				
			]
		);	

		$this->add_control(
			'sec_bgimage',
			[
				'label' => esc_html__( 'Background', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,

			]
		);		
		
		$this->add_control(
			'sec_bgimage_opacity',
			[
				'label' => esc_html__( 'Background Opacity', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::SLIDER ,
				'range' => [
					
					'%' => [
						'min' => 0,
						'max' => 1,
						'step' => 0.1,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 0.5,
				],
				'selectors' => [
					'{{WRAPPER}} .banner:before' => 'opacity: {{SIZE}};',
				],

			]
		);	
		$this->add_control(
			'sec_secimage',
			[
				'label' => esc_html__( 'Section Image', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,

			]
		);	
		
		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => ' Expert instruction ',
			]
		);	
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'It\'s time to amplify your online business',
			]
		);	
		
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Eduhash is a HTML5 template based on Sass and Bootstrap 4 with modern and creative multipurpose design you can use it as a startups.',
			]
		);			
		
		$this->add_control(
			'sec_1st_btn_text',
			[
				'label' => esc_html__( 'First Button Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'our Courses ',
			]
		);			
		
		$this->add_control(
			'sec_1st_btn_link',
			[
				'label' => esc_html__( 'First Button Link', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '# ',
			]
		);		
		
		$this->add_control(
			'sec_2nd_btn_text',
			[
				'label' => esc_html__( '2nd Button Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Sign up',
			]
		);			
		
		$this->add_control(
			'sec_2nd_btn_link',
			[
				'label' => esc_html__( 'First Button Link', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '# ',
			]
		);	
		
		$this->end_controls_section();


	}
	
	protected function render(){		

		$sec_style = $this->get_settings_for_display( 'sec_style' );
		$sec_bgimage = $this->get_settings_for_display( 'sec_bgimage' )['url'];
		$sec_secimage = $this->get_settings_for_display( 'sec_secimage' )['url'];
		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		$sec_1st_btn_text = $this->get_settings_for_display( 'sec_1st_btn_text' );
		$sec_1st_btn_link = $this->get_settings_for_display( 'sec_1st_btn_link' );
		$sec_2nd_btn_text = $this->get_settings_for_display( 'sec_2nd_btn_text' );
		$sec_2nd_btn_link = $this->get_settings_for_display( 'sec_2nd_btn_link' );
		
		?>

	<?php if($sec_style == '1'){ ?>
		<section class="banner" style="background-image: url(<?php echo esc_url($sec_bgimage);?>);">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-md-12 col-xl-7">
						<div class="banner-content text-center">
							<span class="subheading"><?php echo eduhap_wp_kses($sec_subtitle);?></span>
							<h1><?php echo eduhap_wp_kses($sec_title);?></h1>
							<p><?php echo eduhap_wp_kses($sec_content);?></p>
							<?php if($sec_1st_btn_link){ ?>
							<a href="<?php echo esc_url($sec_1st_btn_link);?>" class="btn btn-main me-2"><?php echo esc_html($sec_1st_btn_text);?></a> 
							<?php } if($sec_2nd_btn_link){ ?>							
							<a href="<?php echo esc_url($sec_2nd_btn_link);?>" class="btn btn-tp"><?php echo esc_html($sec_2nd_btn_text);?></a> 
							<?php } ?>							
						</div>
					</div>
				</div> <!-- / .row -->
			</div> <!-- / .container -->
		</section>
	<?php }elseif($sec_style == '2'){ ?>
	
		<section class="banner-2 section-padding">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-12 col-xl-6 col-lg-6">
						<div class="banner-content">
							<span class="subheading"><?php echo eduhap_wp_kses($sec_subtitle);?></span>
							<h1><?php echo eduhap_wp_kses($sec_title);?></h1>
							<p><?php echo eduhap_wp_kses($sec_content);?></p>
							<?php if($sec_1st_btn_link){ ?>
							<a href="<?php echo esc_url($sec_1st_btn_link);?>" class="btn btn-main"><?php echo esc_html($sec_1st_btn_text);?></a> 
							<?php } ?>							
 
						</div>
					</div>

					<div class="col-md-12 col-xl-6 col-lg-6">
						<div class="banner-img-round mt-5 mt-lg-0">
							<img src="<?php echo esc_url($sec_secimage);?>" alt="" class="img-fluid">
						</div>
					</div>
				</div> <!-- / .row -->
			</div> <!-- / .container -->
		</section>	
		
		<?php }elseif($sec_style == '3'){ ?>

		<section class="banner-4 section-padding">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-md-12 col-xl-10">
						<div class="banner-content text-center">
							<span class="subheading"><?php echo eduhap_wp_kses($sec_subtitle);?></span>
							<h1><?php echo eduhap_wp_kses($sec_title);?></h1>
							<p class="mb-4"><?php echo eduhap_wp_kses($sec_content);?></p>
							<?php if($sec_1st_btn_link){ ?>
							<a href="<?php echo esc_url($sec_1st_btn_link);?>" class="btn btn-main me-2"><?php echo esc_html($sec_1st_btn_text);?></a> 
							<?php } if($sec_2nd_btn_link){ ?>							
							<a href="<?php echo esc_url($sec_2nd_btn_link);?>" class="btn btn-solid-border"><?php echo esc_html($sec_2nd_btn_text);?></a> 
							<?php } ?>									

						</div>
					</div>
				</div> <!-- / .row -->
			</div> <!-- / .container -->
		</section>	
	<?php } ?>
<?php

	}

}
