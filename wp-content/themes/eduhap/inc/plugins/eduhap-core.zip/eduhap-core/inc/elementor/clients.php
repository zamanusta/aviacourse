<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapClientsUpWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'eduhap-clients';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Clients' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_clients',
			[
				'label' => esc_html__( 'Clients', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'client_style', [
				'label' => esc_html__( 'Style', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'options' => [
					'1'  => esc_html__( '1', 'eduhap' ),
					'2' => esc_html__( '2', 'eduhap' ),
				],				
				'default' => '1',

			]
		);		
		

		$this->add_control(
			'client_subtitle', [
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => ' Maximize your potentials ',

			]
		);	
		
		$this->add_control(
			'client_title', [
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'default' => 'Over 50k+ people Love to work with us',

			]
		);	
		

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'client_img', [
				'label' => esc_html__( 'Image', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
			]
		);			
		
		$repeater->add_control(
			'client_link', [
				'label' => esc_html__( 'Link', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		

		$this->add_control(
			'clients_options',
			[
				'label' => esc_html__
				( 'Clients Options', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),		
			]
		);			
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$client_style = $this->get_settings_for_display( 'client_style' );
		$client_subtitle = $this->get_settings_for_display( 'client_subtitle' );
		$client_title = $this->get_settings_for_display( 'client_title' );
		$clients_options = $this->get_settings_for_display( 'clients_options' );

		if($client_style == '1'){	
		
		?>

	
		<section class="cta-2 clients">
			<div class="container">
				<div class="row ">
					<div class="col-xl-10">
						<div class="section-heading ">
							<span class="subheading"><?php echo esc_html($client_subtitle);?></span>
							<h3><?php echo eduhap_wp_kses($client_title);?></h3>
						</div>
					</div>
				</div>

				<div class="row mx-auto">
					<?php
						foreach ($clients_options as $item ) { ?>						
							<div class="col-lg-3 col-sm-6 col-xl-2">
								<div class="client-logo">
									<a href="<?php echo esc_url($item['client_link']);?>"><img src="<?php echo esc_url($item['client_img']['url']);?>" alt="" class="img-fluid"></a>
								</div>
							</div>
								
					<?php } ?>				

				</div>
			</div>
		</section>
		
		<?php }else{ ?>

		<section class="clients-2">
			<div class="container">
				<div class="row mx-auto">
				<?php
					foreach ($clients_options as $item ) { ?>						
						<div class="col-lg-3 col-sm-6 col-xl-2">
							<div class="client-logo">
								<a href="<?php echo esc_url($item['client_link']);?>"><img src="<?php echo esc_url($item['client_img']['url']);?>" alt="" class="img-fluid"></a>
							</div>
						</div>
							
				<?php } ?>				

					 
				</div>
			</div>
		</section>
		
	
		<?php } ?>
<?php
		
	}

}
