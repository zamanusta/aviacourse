<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapNewsletterWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-newsletter';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Newsletter' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_newsletter',
			[
				'label' => esc_html__( 'Newsletter', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Newsletter',
			]
		);	
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'newsletter', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Subscribe to get latest news',
			]
		);	
		
		$this->add_control(
			'sec_newsletter',
			[
				'label' => esc_html__( 'Enter Shortcode', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,

			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_newsletter = $this->get_settings_for_display( 'sec_newsletter' );

		
		?>

		<section class="subscribe">
			<div class="container">
				<div class="row align-items-center form-inner">
					<div class="col-lg-6 col-xl-6">
						<div class="section-heading mb-0">
							<span class="subheading"><?php echo esc_html($sec_subtitle);?></span>
							<h3><?php echo eduhap_wp_kses($sec_title);?></h3>
						</div>
					</div>
					<div class="col-lg-6 col-xl-6">
						<div class="subscribe-form">
							<?php echo do_shortcode($sec_newsletter);?>
						</div>
					</div>
				</div>
			</div>
		</section>

<?php

	}

}
