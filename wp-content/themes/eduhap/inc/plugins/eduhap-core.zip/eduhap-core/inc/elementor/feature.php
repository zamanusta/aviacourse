<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapFeatureWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-feature';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Feature' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_feature',
			[
				'label' => esc_html__( 'Feature', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_feature_style',
			[
				'label' => esc_html__( 'Style', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( '1', 'eduhap' ),
					'2' => esc_html__( '2', 'eduhap' ),
					'3' => esc_html__( '3', 'eduhap' ),
	
				],
				
			]
		);	
	
		$this->add_control(
			'sec_icon',
			[
				'label' => esc_html__( 'Icon', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'flaticon-flag',
			]
		);	
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Expert Teacher',
			]
		);	
		
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Develop skills for career of various majors including computer',
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_feature_style = $this->get_settings_for_display( 'sec_feature_style' );
		$sec_icon = $this->get_settings_for_display( 'sec_icon' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		
		?>
		<?php if($sec_feature_style == '2'){ ?>
			<div class="feature-4 feature-item">
				<div class="feature-icon">
					<i class="<?php echo esc_attr($sec_icon);?>"></i>
				</div>
				<div class="feature-text">
					<h4><?php echo esc_html($sec_title);?></h4>
					<p><?php echo eduhap_wp_kses($sec_content);?></p>
				</div>
			</div>
		<?php }elseif($sec_feature_style == '3'){ ?>
			<div class="feature-item feature-style-2">
				<div class="feature-icon">
					<i class="<?php echo esc_attr($sec_icon);?>"></i>
				</div>
				<div class="feature-text">
					<h4><?php echo esc_html($sec_title);?></h4>
					<p><?php echo eduhap_wp_kses($sec_content);?></p>
				</div>
			</div>			
		<?php }else{ ?>
		<div class="feature-item">
			<div class="feature-icon">
				<i class="<?php echo esc_attr($sec_icon);?>"></i>
			</div>
			<div class="feature-text">
				<h4><?php echo esc_html($sec_title);?></h4>
				<p><?php echo eduhap_wp_kses($sec_content);?></p>
			</div>
		</div>
		<?php } ?>
<?php

	}

}
