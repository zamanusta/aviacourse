<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapArchiveCoursesWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-archive-courses';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Archive Courses' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_archive_courses',
			[
				'label' => esc_html__( 'Archive Courses', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'se_style',
			[
				'label' => esc_html__( 'Style', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'default' => '1',
				'options' => [
					'1' => esc_html__( '1', 'eduhap' ),
					'2'  => esc_html__( '2', 'eduhap' ),
					'3'  => esc_html__( '3', 'eduhap' ),
				],
			]
		);
		

		$this->add_control(
			'se_num_post',
			[
				'label' => esc_html__( 'Pagination number of Post', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '6',
				
			]
		);
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$se_style = $this->get_settings_for_display( 'se_style' );
		$se_num_post = $this->get_settings_for_display( 'se_num_post' );
		global $post, $authordata;
		?>
<section class="section-padding course">

   <div class="container">
        <div class="row">
			<?php		
		$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
		$args = array(
			'post_type' => 'courses',
			'posts_per_page' => $se_num_post,
			'paged' => $paged
		);
		$loop = new WP_Query( $args );
		while ( $loop->have_posts() ) : $loop->the_post();
		$course_id         = get_the_ID();
		$course_students   = apply_filters( 'tutor_course_students', tutor_utils()->count_enrolled_users_by_course( $course_id ), $course_id );
		$course_duration = get_tutor_course_duration_context( $course_id, true );
		$course_categories = get_tutor_course_categories( $course_id );	
		$profile_url       = tutor_utils()->profile_url( $authordata->ID, true );
			if($se_style == '2'){
				
			?>
						<div class="col-lg-4 col-md-6">
							<div class="course-block">
								<div class="course-img">
									<?php the_post_thumbnail('eduhap_course');?>
									<div class="course-price ">
										<?php
											$price = tutor_utils()->get_course_price();
										if ( null === $price ) {
											esc_html_e( 'Free', 'tutor' );
										} else {
											echo wp_kses_post( tutor_utils()->get_course_price() );
										}
										?>										
									</div>   
								</div>
								
								<div class="course-content">
									<span class="course-cat"> 
											<?php
											$category_links = array();
											foreach ( $course_categories as $course_category ) :
												$category_name    = $course_category->name;
												$category_link    = get_term_link( $course_category->term_id );
												$category_links[] = wp_sprintf( '<a href="%1$s">%2$s</a>', esc_url( $category_link ), esc_html( $category_name ) );
												endforeach;
												echo wp_kses(
													implode( ', ', $category_links ),
													array( 'a' => array( 'href' => true ) )
												);
											?>			
										</span>
									<h4><a href="<?php the_permalink();?>"><?php echo the_title();?></a></h4>       
									
									<div class="course-meta">
										<span class="course-student"><i class="fa fa-user-alt"></i> <?php echo esc_html( $course_students ); ?> <?php echo esc_html__('Students' , 'eduhap');?></span>
										<span class="course-duration"><i class="far fa-file-alt"></i> <?php echo esc_html( tutor_utils()->get_lesson_count_by_course( $course_id ) ) ?> <?php echo esc_html__('Lessons' , 'eduhap');?></span>
									</div> 
								</div>
							</div>
						</div>
			<?php
			}elseif($se_style == '3'){ ?>
						<div class="col-lg-6 col-md-12">
								<div class="course-block course-list-item">
									<div class="row align-items-center">
										<div class="col-lg-4 col-sm-4 ">
											<div class="course-img mb-4 mb-md-0">
												<?php the_post_thumbnail('eduhap_course_two');?>
											</div>
										</div>
										<div class="col-lg-8  col-sm-8">
											<div class="course-content">
												<div class="course-price ">
													<?php
														$price = tutor_utils()->get_course_price();
													if ( null === $price ) {
														esc_html_e( 'Free', 'eduhap' );
													} else {
														echo wp_kses_post( tutor_utils()->get_course_price() );
													}
													?>
												</div>   
												<h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>    
												<div class="course-meta">
													<span class="course-author"><?php echo esc_html__('By' , 'eduhap');?> <a href="<?php echo esc_url( $profile_url ); ?>"><?php echo esc_html( get_the_author() ); ?></a></span>
													<span class="course-duration"><i class="far fa-file-alt"></i> <?php echo esc_html( tutor_utils()->get_lesson_count_by_course( $course_id ) ) ?> <?php echo esc_html__('Lessons' , 'eduhap');?></span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>			
			<?php }else{ ?>
						<div class="col-lg-4 col-md-6">
							<div class="course-block">
								<div class="course-img">
									<?php the_post_thumbnail('eduhap_course');?>
									<div class="course-price ">
										<?php
											$price = tutor_utils()->get_course_price();
										if ( null === $price ) {
											esc_html_e( 'Free', 'tutor' );
										} else {
											echo wp_kses_post( tutor_utils()->get_course_price() );
										}
										?>										
									</div>   
								</div>
								
								<div class="course-content">
									<span class="course-cat"> 
											<?php
											$category_links = array();
											foreach ( $course_categories as $course_category ) :
												$category_name    = $course_category->name;
												$category_link    = get_term_link( $course_category->term_id );
												$category_links[] = wp_sprintf( '<a href="%1$s">%2$s</a>', esc_url( $category_link ), esc_html( $category_name ) );
												endforeach;
												echo wp_kses(
													implode( ', ', $category_links ),
													array( 'a' => array( 'href' => true ) )
												);
											?>			
										</span>
									<h4><a href="<?php the_permalink();?>"><?php echo the_title();?></a></h4>       
									<p class="mb-3"><?php echo eduhap_trip_content(13);?></p>
									<div class="course-meta">
										<span class="course-student"><i class="fa fa-user-alt"></i> <?php echo esc_html( $course_students ); ?> <?php echo esc_html__('Students' , 'eduhap');?></span>
										<span class="course-duration"><i class="far fa-file-alt"></i> <?php echo esc_html( tutor_utils()->get_lesson_count_by_course( $course_id ) ) ?> <?php echo esc_html__('Lessons' , 'eduhap');?></span>
									</div> 
								</div>
							</div>
						</div>					
			<?php }
		
		endwhile;
			?>
			
			
<div class="navigation pagination cours_pag">
     <?php
     $big = 999999999;
     echo paginate_links( array(
          'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
          'format' => '?paged=%#%',
          'current' => max( 1, get_query_var('paged') ),
          'total' => $loop->max_num_pages,
          'prev_text' => '&laquo;',
          'next_text' => '&raquo;'
     ) );
?>
</div>
<?php wp_reset_postdata(); ?>
       </div>
		
    </div>
</section>
		<?php


	}

}
