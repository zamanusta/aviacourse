<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapButtonsWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-buttons';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Buttons' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_buttons',
			[
				'label' => esc_html__( 'Buttons', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_button_style',
			[
				'label' => esc_html__( 'Style', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Border', 'eduhap' ),
					'2' => esc_html__( 'Background', 'eduhap' ),
	
				],
				
			]
		);	
	
		$this->add_control(
			'sec_text',
			[
				'label' => esc_html__( 'Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Sign Up',
			]
		);	
		
		$this->add_control(
			'sec_link',
			[
				'label' => esc_html__( 'Link', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);	
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_button_style = $this->get_settings_for_display( 'sec_button_style' );
		$sec_text = $this->get_settings_for_display( 'sec_text' );
		$sec_link = $this->get_settings_for_display( 'sec_link' );
		
		if($sec_button_style == '1'){ ?>
			<a href="<?php echo esc_url($sec_link);?>" class="btn btn-solid-border btn-sm "><?php echo esc_html($sec_text);?></a>
		<?php }else{ ?>
		
			<a href="<?php echo esc_url($sec_link);?>" class="btn btn-main btn-sm"><?php echo esc_html($sec_text);?></a>
		<?php }
		?>

		
		

<?php

	}

}
