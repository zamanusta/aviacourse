<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapCounterUpWidget extends Elementor\Widget_Base{
	public function get_name() {
		
		return 'eduhap-counter-up';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Counter Up' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_counter_up',
			[
				'label' => esc_html__( 'Counter Up', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'count_style', [
				'label' => esc_html__( 'Style', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'options' => [
					'1'  => esc_html__( '1', 'eduhap' ),
					'2' => esc_html__( '2', 'eduhap' ),
				],				
				'default' => '1',

			]
		);		
		
		$this->add_control(
			'count_bg_color', [
				'label' => esc_html__( 'Background Color', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'label_block' => true,
				'selectors' => [
					'{{WRAPPER}} .counter_area' => 'background: {{VALUE}}',
				],

			]
		);	
		
		$this->add_control(
			'count_subtitle', [
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => ' Maximize your potentials ',

			]
		);	
		
		$this->add_control(
			'count_title', [
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'default' => 'We break down barriers so teams can focus on what matters – learning together to create online career you love.',

			]
		);	
		

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'coun_title', [
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);			
		
		$repeater->add_control(
			'count_number', [
				'label' => esc_html__( 'Number', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		

		$repeater->add_control(
			'count_number_percent', [
				'label' => esc_html__( 'If Percent', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'count_text', [
				'label' => esc_html__( 'Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);		
		

		$this->add_control(
			'counter_options',
			[
				'label' => esc_html__
				( 'Counter Options', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																															
						'coun_title' => 'Instructors',							
						'count_number' => '90',																																																					
						'count_text' => 'Tempus imperdiet nulla malpellen tesque Malesuada libero',																																																																																																			
																																																										
					],
		
				],

			]
		);			
		
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'count_icon', [
				'label' => esc_html__( 'Icon', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		

		$repeater->add_control(
			'coun_title', [
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);			
		
		$repeater->add_control(
			'count_number', [
				'label' => esc_html__( 'Number', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		

		$repeater->add_control(
			'countn_percent', [
				'label' => esc_html__( 'If Percent', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		

		$this->add_control(
			'counter_style_two_options',
			[
				'label' => esc_html__
				( 'Counter Style Two', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																															
						'count_icon' => 'flaticon-video-camera',							
						'coun_title' => 'Instructors',							
						'count_number' => '90',																																																																																																			
																																																										
					],
		
				],

			]
		);	

		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$count_style = $this->get_settings_for_display( 'count_style' );
		$count_subtitle = $this->get_settings_for_display( 'count_subtitle' );
		$count_title = $this->get_settings_for_display( 'count_title' );
		$counter_options = $this->get_settings_for_display( 'counter_options' );
		$counter_style_two_options = $this->get_settings_for_display( 'counter_style_two_options' );

		if($count_style == '1'){	
		
		?>

	
		<section class="counter-section section-padding">
			<div class="container">
				<div class="row">
					<div class="col-xl-10">
						<div class="section-heading">
							<span class="subheading"><?php echo esc_html($count_subtitle);?></span>
							<h3><?php echo eduhap_wp_kses($count_title);?></h3>
						</div>
					</div>
				</div>
			   
				<div class="row">
					<?php
						foreach ($counter_options as $item ) { ?>						
							<div class="col-lg-3 col-md-6">
								<div class="counter-item">
									<h6><?php echo esc_html($item['coun_title']);?></h6>
									<div class="count">
										<?php if($item['count_number_percent']){ ?>
											<span class="counter"><?php echo esc_html($item['count_number_percent']);?></span> %
										<?php }else{ ?>
											<span class="counter"><?php echo esc_html($item['count_number']);?></span>
										<?php } ?>
										
									</div>
									<p><?php echo eduhap_wp_kses($item['count_text']);?></p>
								</div>
							</div>	
							
					<?php } ?>					

			   </div>
			</div>
		</section>	
		<?php }else{ ?>
		<section class="counter-block">
			<div class="container">
				<div class="row">
					<div class="col-xl-12 bg-black counter-inner counter_area">
						<div class="row">
							<?php
								foreach ($counter_style_two_options as $item ) { ?>						

								<div class="col-lg-3 col-md-6 col-sm-6">
									<div class="counter-item text-center">
										<i class="<?php echo esc_attr($item['count_icon']);?>"></i>
										<div class="count">
											<?php if($item['countn_percent']){ ?>
											<span class="counter"><?php echo esc_html($item['countn_percent']);?></span> %
										<?php }else{ ?>
											<span class="counter"><?php echo esc_html($item['count_number']);?></span>
										<?php } ?>
											
											
										</div>
										<h6><?php echo esc_html($item['coun_title']);?></h6>
									</div>
								</div>
							
							<?php } ?>							

						</div>
					</div>
			   </div>
			</div>
		</section>		
		<?php } ?>
<?php
		
	}

}
