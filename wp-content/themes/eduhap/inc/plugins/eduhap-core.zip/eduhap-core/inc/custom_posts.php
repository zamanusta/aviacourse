<?php


if ( ! function_exists('eduhap_testimonials') ) {

// Register Testimonial Post Type
function eduhap_testimonials() {

	$labels = array(
		'name'                  => esc_html_x( 'Testimonials', 'Post Type General Name', 'eduhap' ),
		'singular_name'         => esc_html_x( 'Testimonial', 'Post Type Singular Name', 'eduhap' ),
		'menu_name'             => esc_html__( 'Testimonials', 'eduhap' ),
		'name_admin_bar'        => esc_html__( 'Testimonials', 'eduhap' ),
		'archives'              => esc_html__( 'Item Archives', 'eduhap' ),
		'attributes'            => esc_html__( 'Item Attributes', 'eduhap' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'eduhap' ),
		'all_items'             => esc_html__( 'All Items', 'eduhap' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'eduhap' ),
		'add_new'               => esc_html__( 'Add New', 'eduhap' ),
		'new_item'              => esc_html__( 'New Item', 'eduhap' ),
		'edit_item'             => esc_html__( 'Edit Item', 'eduhap' ),
		'update_item'           => esc_html__( 'Update Item', 'eduhap' ),
		'view_item'             => esc_html__( 'View Item', 'eduhap' ),
		'view_items'            => esc_html__( 'View Items', 'eduhap' ),
		'search_items'          => esc_html__( 'Search Item', 'eduhap' ),
		'not_found'             => esc_html__( 'Not found', 'eduhap' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'eduhap' ),
		'featured_image'        => esc_html__( 'Featured Image', 'eduhap' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'eduhap' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'eduhap' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'eduhap' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'eduhap' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'eduhap' ),
		'items_list'            => esc_html__( 'Items list', 'eduhap' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'eduhap' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'eduhap' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Testimonial', 'eduhap' ),
		'description'           => esc_html__( 'Post Type Description', 'eduhap' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-format-chat',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'testimonials', $args );

}
add_action( 'init', 'eduhap_testimonials', 0 );

}

if ( ! function_exists('eduhap_team') ) {

// Register Custom Post Type
function eduhap_team() {

	$labels = array(
		'name'                  => esc_html_x( 'Team', 'Post Type General Name', 'eduhap' ),
		'singular_name'         => esc_html_x( 'Team', 'Post Type Singular Name', 'eduhap' ),
		'menu_name'             => esc_html__( 'Team', 'eduhap' ),
		'name_admin_bar'        => esc_html__( 'Team', 'eduhap' ),
		'archives'              => esc_html__( 'Item Archives', 'eduhap' ),
		'attributes'            => esc_html__( 'Item Attributes', 'eduhap' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'eduhap' ),
		'all_items'             => esc_html__( 'All Items', 'eduhap' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'eduhap' ),
		'add_new'               => esc_html__( 'Add New', 'eduhap' ),
		'new_item'              => esc_html__( 'New Item', 'eduhap' ),
		'edit_item'             => esc_html__( 'Edit Item', 'eduhap' ),
		'update_item'           => esc_html__( 'Update Item', 'eduhap' ),
		'view_item'             => esc_html__( 'View Item', 'eduhap' ),
		'view_items'            => esc_html__( 'View Items', 'eduhap' ),
		'search_items'          => esc_html__( 'Search Item', 'eduhap' ),
		'not_found'             => esc_html__( 'Not found', 'eduhap' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'eduhap' ),
		'featured_image'        => esc_html__( 'Featured Image', 'eduhap' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'eduhap' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'eduhap' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'eduhap' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'eduhap' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'eduhap' ),
		'items_list'            => esc_html__( 'Items list', 'eduhap' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'eduhap' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'eduhap' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Team', 'eduhap' ),
		'description'           => esc_html__( 'Post Type Description', 'eduhap' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'thumbnail' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-admin-users',		
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'team', $args );

}
add_action( 'init', 'eduhap_team', 0 );

}