<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }


    // This is your option name where all the Redux data is stored.
    $opt_name = "eduhap";

    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'eduhap/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */


    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,

         'disable_tracking' => true,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => esc_html__( 'Eduhap Options', 'eduhap' ),
        'page_title'           => esc_html__( 'Eduhap Options', 'eduhap' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => false,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => false,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => 2,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

    );

 

    // Panel Intro text -> before the form
    if ( ! isset( $args['global_variable'] ) || $args['global_variable'] !== false ) {
        if ( ! empty( $args['global_variable'] ) ) {
            $v = $args['global_variable'];
        } else {
            $v = str_replace( '-', '_', $args['opt_name'] );
        }
        $args['intro_text'] = sprintf( esc_html__( '', 'eduhap' ), $v );
    } else {
        $args['intro_text'] = esc_html__( '', 'eduhap' );
    }

    // Add content after the form.
    $args['footer_text'] = esc_html__( '', 'eduhap' );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */



    // -> START Basic Fields

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'General Settings', 'eduhap' ),
        'id'               => 'eduhap-general-setting',
        'customizer_width' => '400px',
        'fields'           => array(

			array(
                'id'       => 'eduhap_header_opt',
                'type'     => 'info',
                'style'     => 'success',
                'title'    => esc_html__('Header Section', 'eduhap'),
            ), 
			
            array(
                'id'       => 'eduhap_header_style_opt',
                'type'     => 'select',
                'title'    => esc_html__('Header Style', 'eduhap'),
                'subtitle' => esc_html__('Select option here', 'eduhap'),
				'options'  => array(
					'1' => 'One',
					'2' => 'Two',
					'3' => 'Three',
					'4' => 'Four',
				),
				'default'  => '1',
            ), 
			
            array(
                'id'       => 'eduhap_header_top_opt',
                'type'     => 'switch',
                'title'    => esc_html__('Header Top Option', 'eduhap'),
                'subtitle' => esc_html__('If yes then click the checkbox.', 'eduhap'),
                'default'  => '1'// 1 = on | 0 = off
            ), 	
			
			array(
                'id'       => 'eduhap_header_top_text',
                'type'             => 'textarea',
                'title'            => esc_html__('Header Top Text', 'eduhap'), 
				'default'  => 'Are you interested in Joining program? <a href="#">Contact me.</a>',
                'subtitle'         => esc_html__('write text here', 'eduhap'),
				'required' => array( 'eduhap_header_top_opt', '=', '1' ),
            ),			
			
			array(
                'id'       => 'eduhap_header_log_btn_text',
                'type'             => 'text',
                'title'            => esc_html__('Header Login Button Text', 'eduhap'), 
				'default'  => 'Login',
                'subtitle'         => esc_html__('write text here', 'eduhap'),
            ),
			
			array(
                'id'       => 'eduhap_header_log_btn_link',
                'type'             => 'text',
                'title'            => esc_html__('Login Button Link', 'eduhap'), 
				'default'  => '#',
                'subtitle'         => esc_html__('enter link here', 'eduhap'),
            ),			
			
			array(
                'id'       => 'eduhap_header_sign_btn_text',
                'type'             => 'text',
                'title'            => esc_html__('Sign Up Button Text', 'eduhap'), 
				'default'  => 'Sign Up',
                'subtitle'         => esc_html__('write text here', 'eduhap'),
            ),			
			
			array(
                'id'       => 'eduhap_header_sign_btn_link',
                'type'             => 'text',
                'title'            => esc_html__('Sign Up Button Link', 'eduhap'), 
				'default'  => '#',
                'subtitle'         => esc_html__('write text here', 'eduhap'),
            ),			
			
			array(
                'id'       => 'eduhap_header_social_option',
                'type'             => 'slides',
                'title'            => esc_html__('Social Option', 'eduhap'), 
                'subtitle'         => esc_html__('write text here', 'eduhap'),
				'placeholder' => array(
					'title'           => esc_html__('Write icon name', 'eduhap'),
					'url'             => esc_html__('Enter link', 'eduhap'),
				),				
				'show' => array(
					'title' => true,
					'url' => true,
					'description' => false,
					'thumb' => false,
				)
            ),
			
			
            array(
                'id'       => 'eduhap_preloader_opt',
                'type'     => 'switch',
                'title'    => esc_html__('Display Preloader', 'eduhap'),
                'subtitle' => esc_html__('If yes then click the checkbox.', 'eduhap'),
                'default'  => '1'// 1 = on | 0 = off
            ), 	
			
			array(
                'id'       => 'eduhap_homepage_opt',
                'type'             => 'checkbox',
                'title'            => esc_html__('Only Enable Home Page', 'eduhap'), 
				'default'  => '0',
                'subtitle'         => esc_html__('if check this option preloader only will be enable for home page', 'eduhap'),
				'required' => array( 'eduhap_preloader_opt', '=', '1' ),
            )				
			

        )
    ) );


    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Banner Settings', 'eduhap' ),
        'id'               => 'eduhap-banner-setting',
        'customizer_width' => '400px',
        'fields'           => array(
		
			array(
				'id'       => 'eduhap_home_title',
				'type'     => 'text',
				'title'    => esc_html__('Home Page Title', 'eduhap'), 
				'subtitle' => esc_html__('enter text here ', 'eduhap'),
				'transparent'     => false,
				'default'  => 'Home'
			),		
			
			array(
				'id'       => 'eduhap_archive_title',
				'type'     => 'text',
				'title'    => esc_html__('Archive Page Title', 'eduhap'), 
				'subtitle' => esc_html__('enter text here ', 'eduhap'),
				'transparent'     => false,
				'default'  => 'Archive'
			),		
			
			array(
				'id'       => 'eduhap_blog_title',
				'type'     => 'text',
				'title'    => esc_html__('Blog Page Title', 'eduhap'), 
				'subtitle' => esc_html__('enter text here ', 'eduhap'),
				'transparent'     => false,
				'default'  => 'Blog'
			),				
			
			array(
				'id'       => 'eduhap_search__title',
				'type'     => 'text',
				'title'    => esc_html__('Search Page Title', 'eduhap'), 
				'subtitle' => esc_html__('enter text here ', 'eduhap'),
				'transparent'     => false,
				'default'  => 'Search Result'
			),	
			
			array(
				'id'       => 'eduhap_course_title',
				'type'     => 'text',
				'title'    => esc_html__('Course Page Title', 'eduhap'), 
				'subtitle' => esc_html__('enter text here ', 'eduhap'),
				'transparent'     => false,
				'default'  => 'Course'
			),				
								
        )
    ) );    
	
	Redux::setSection( $opt_name, array(
        'title'            => esc_html__( '404 Page Settings', 'eduhap' ),
        'id'               => 'eduhap-404-page-setting',
        'customizer_width' => '400px',
        'fields'           => array(
	

			array(
				'id'       => 'eduhap_404_page_title',
				'type'     => 'text',
				'title'    => esc_html__('Page Title', 'eduhap'), 
				'subtitle' => esc_html__('enter text here ', 'eduhap'),
				'transparent'     => false,
				'default'  => '404'
			),
			
			array(
				'id'       => 'eduhap_404_page_subtitle',
				'type'     => 'textarea',
				'title'    => esc_html__('Page Subtitle', 'eduhap'), 
				'subtitle' => esc_html__('enter text here ', 'eduhap'),
				'transparent'     => false,
				'default'  => 'Oops! That page can’tdfdsf'
			),	
			
			array(
				'id'       => 'eduhap_404_page_descrption',
				'type'     => 'textarea',
				'title'    => esc_html__('Page Description', 'eduhap'), 
				'subtitle' => esc_html__('enter text here ', 'eduhap'),
				'transparent'     => false,
				'default'  => 'It looks like nothing was found at this location. Maybe try one of the links below or a search?'
			),			
			
			array(
				'id'       => 'eduhap_404_btn_text',
				'type'     => 'text',
				'title'    => esc_html__('Button Text', 'eduhap'), 
				'subtitle' => esc_html__('enter text here ', 'eduhap'),
				'transparent'     => false,
				'default'  => 'Back To Home Page'
			)	

		
        )
    ) );	
	

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Colors / Typography Settings', 'eduhap' ),
        'id'               => 'eduhap-custom-css-setting',
        'customizer_width' => '400px',
        'fields'           => array(
		
			array(
                'id'       => 'eduhap_custom_css_opt',
                'type'     => 'switch',
                'title'    => esc_html__('Colors/ Typography Option', 'eduhap'),
                'subtitle' => esc_html__('Show / hide banner Image', 'eduhap'),
                'default'  => '0'// 1 = on | 0 = off
            ), 
			
			array(
				'id'       => 'eduhap_typography_col_opt',
				'type'     => 'info',
				'style'     => 'success',
				'title'    => esc_html__('Typography', 'eduhap'), 
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
			),	
			
			array(
				'id'       => 'eduhap_body_typo',
				'title'    => esc_html__('Body Font', 'eduhap'),
				'subtitle'    => esc_html__('Select style', 'eduhap'),
				'type' => 'typography',
				'font-backup' => false,
				'subsets' => false,
				'font-style' => true,
				'font-weight' => true,
				'font-family' => true,
				'font-size' => false,
				'text-align' => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'output'      => array('body, p'),
			),			
			
			array(
				'id'       => 'eduhap_menu_typo',
				'title'    => esc_html__('Menu Font', 'eduhap'),
				'subtitle'    => esc_html__('Select style', 'eduhap'),
				'type' => 'typography',
				'font-backup' => false,
				'subsets' => false,
				'font-style' => true,
				'font-weight' => true,
				'font-family' => true,
				'font-size' => false,
				'color' => false,
				'text-align' => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'output'      => array('#navbarMenu li a, .header-top'),
			),			
			
			array(
				'id'       => 'eduhap_btntypo',
				'title'    => esc_html__('Button Font', 'eduhap'),
				'subtitle'    => esc_html__('Select style', 'eduhap'),
				'type' => 'typography',
				'font-backup' => false,
				'subsets' => false,
				'font-style' => true,
				'font-weight' => true,
				'font-family' => true,
				'font-size' => false,
				'color' => false,
				'text-align' => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'output'      => array('.btn'),
			),			
			
			array(
				'id'       => 'eduhap_heading_text_typo',
				'title'    => esc_html__('Heading Font', 'eduhap'),
				'subtitle'    => esc_html__('Select style', 'eduhap'),
				'type' => 'typography',
				'font-backup' => false,
				'subsets' => false,
				'font-style' => true,
				'font-weight' => true,
				'font-family' => true,
				'font-size' => false,
				'color' => true,
				'text-align' => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'output'      => array('.h1, .h2, .h3, .h4, .h5, .h6, h1, h2, h3, h4, h5, h6'),
			),

			array(
				'id'       => 'eduhap_subheading_text_typo',
				'title'    => esc_html__('Subheading Font', 'eduhap'),
				'subtitle'    => esc_html__('Select style', 'eduhap'),
				'type' => 'typography',
				'font-backup' => false,
				'subsets' => false,
				'font-style' => true,
				'font-weight' => true,
				'font-family' => true,
				'font-size' => false,
				'color' => true,
				'text-align' => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'output'      => array('.subheading'),
			),
			
			array(
				'id'       => 'eduhap_theme_color_opt',
				'type'     => 'color',
				'title'    => esc_html__('Theme Color', 'eduhap'),
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,				
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default' => '#20ad96',
			),		

			array(
				'id'       => 'eduhap_border_col_opt',
				'type'     => 'info',
				'style'     => 'success',
				'title'    => esc_html__('Border Button Color', 'eduhap'), 
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
			),
			
			array(
				'id'       => 'eduhap_bor_btn_text_color',
				'type'     => 'color',
				'title'    => esc_html__('Button Text Color', 'eduhap'), 
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#2b3940'
			),
			
			array(
				'id'       => 'eduhap_bor_btn_text_hovercolor',
				'type'     => 'color',
				'title'    => esc_html__('Button Hover Text Color', 'eduhap'), 
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#fff'
			),	
			
			array(
				'id'       => 'eduhap_bor_btn_bg_hovercolor',
				'type'     => 'color',
				'title'    => esc_html__('Button Hover Background Color', 'eduhap'), 
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#2b3940'
			),							

			array(
				'id'       => 'eduhap_backgournd_btn_col_opt',
				'type'     => 'info',
				'style'     => 'success',
				'title'    => esc_html__('Background Button Color', 'eduhap'), 
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
			),
			
			array(
				'id'       => 'eduhap_button_bgcolor_opt',
				'type'     => 'color',
				'title'    => esc_html__('Button BG Color', 'eduhap'),
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,				
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default' => '#20ad96',
			),		
			
			array(
				'id'       => 'eduhap_button_textcolor_opt',
				'type'     => 'color',
				'title'    => esc_html__('Button Text Color', 'eduhap'),
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,				
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default' => '#fff',
			),				
			
			array(
				'id'       => 'eduhap_button_hover_textcolor_opt',
				'type'     => 'color',
				'title'    => esc_html__('Button Hover Text Color', 'eduhap'),
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,				
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default' => '#fff',
			),			
			
			array(
				'id'       => 'eduhap_button_hover_bgcolor_opt',
				'type'     => 'color',
				'title'    => esc_html__('Button Hover BG Color', 'eduhap'),
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,				
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default' => '#3F3A64',
			),		
			

			array(
				'id'       => 'eduhap_header_top_col_opt',
				'type'     => 'info',
				'style'     => 'success',
				'title'    => esc_html__('Header Top Color', 'eduhap'), 
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
			),

			array(
				'id'       => 'eduhap_header_top_bgcolor_opt',
				'type'     => 'color',
				'title'    => esc_html__('Background Color', 'eduhap'),
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,				
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default' => '#385777',
			),	

			array(
				'id'       => 'eduhap_header_top_text_color_opt',
				'type'     => 'color',
				'title'    => esc_html__('Text Color', 'eduhap'),
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,				
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default' => '#fff',
			),	

			array(
				'id'       => 'eduhap_header_top_link_color_opt',
				'type'     => 'color',
				'title'    => esc_html__('Link Color', 'eduhap'),
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,				
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default' => '#fff',
			),

			array(
				'id'       => 'eduhap_header_top_link_hcolor_opt',
				'type'     => 'color',
				'title'    => esc_html__('Link Hover Color', 'eduhap'),
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,				
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default' => '#20ad96',
			),	
			
			array(
				'id'       => 'eduhap_header_col_opt',
				'type'     => 'info',
				'style'     => 'success',
				'title'    => esc_html__('Header Color', 'eduhap'), 
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
			),			
							
		
			array(
				'id'       => 'eduhap_menu_text_color',
				'type'     => 'color',
				'title'    => esc_html__('Menu Text Color', 'eduhap'), 
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#3f3a64'
			),						
			array(
				'id'       => 'eduhap_menu_text_hover_color',
				'type'     => 'color',
				'title'    => esc_html__('Menu Text Hover', 'eduhap'), 
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#20ad96'
			),					
			array(
				'id'       => 'eduhap_sticky_menu_bg_color',
				'type'     => 'color',
				'title'    => esc_html__('Menu Sticky BG Color', 'eduhap'), 
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#fff'
			),		

			array(
				'id'       => 'eduhap_sticky_menu_text_color',
				'type'     => 'color',
				'title'    => esc_html__('Menu Sticky Text Color', 'eduhap'), 
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#3f3a64'
			),	
			
			array(
				'id'       => 'eduhap_submenu_border_color',
				'type'     => 'color',
				'title'    => esc_html__('Submenu Border Top Color', 'eduhap'), 
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#20ad96'
			),	
			
			array(
				'id'       => 'eduhap_submenu_bg_color',
				'type'     => 'color',
				'title'    => esc_html__('Submenu Background Color', 'eduhap'), 
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#ffffff'
			),		
			
			array(
				'id'       => 'eduhap_submenu_text_color',
				'type'     => 'color',
				'title'    => esc_html__('Submenu Text Color', 'eduhap'), 
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#3f3a64'
			),		
					
			array(
				'id'       => 'eduhap_submenu_hover_bg_color',
				'type'     => 'color',
				'title'    => esc_html__('Submenu Hover Background Color', 'eduhap'), 
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#20ad96'
			),	
			
			array(
				'id'       => 'eduhap_submenu_hover_text_color',
				'type'     => 'color',
				'title'    => esc_html__('Submenu Hover text Color', 'eduhap'), 
				'subtitle' => esc_html__('Choice color here', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#fff'
			),			

			array(
				'id'       => 'eduhap_spinning_col_opt',
				'type'     => 'info',
				'style'     => 'success',
				'title'    => esc_html__('Preloader Color', 'eduhap'), 
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
			),	
			
			array(
                'id'       => 'eduhap_spinner_bgcolor',
                'type'             => 'color',
                'title'            => esc_html__('Preloader Background Color', 'eduhap'), 		
                'subtitle'         => esc_html__('choice color here', 'eduhap'),
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'transparent'     => false,
				'default'  => '#ffffff'
            ),			

			array(
                'id'       => 'eduhap_spinner_border_color',
                'type'             => 'color',
                'title'            => esc_html__('Preloader Border Color', 'eduhap'), 		
                'subtitle'         => esc_html__('choice color here', 'eduhap'),
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'transparent'     => false,
				'default'  => '#fafafa'
            ),	
			
			array(
                'id'       => 'eduhap_spinner_color',
                'type'             => 'color',
                'title'            => esc_html__('Preloader Color', 'eduhap'), 		
                'subtitle'         => esc_html__('choice color here', 'eduhap'),
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'transparent'     => false,
				'default'  => '#20ad96'
            ),	
			
			
			array(
				'id'       => 'eduhap_footer_col_opt',
				'type'     => 'info',
				'style'     => 'success',
				'title'    => esc_html__('Footer Color', 'eduhap'), 
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
			),
			
			array(
				'id'       => 'eduhap_footer_backgorund_color',
				'type'     => 'color',
				'title'    => esc_html__('Footer Backgrund Color', 'eduhap'), 
				'subtitle' => esc_html__('Please use color ', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default' => '#EBF4F8'
			),				
							
			
			
			array(
				'id'       => 'eduhap_footer_title_color',
				'type'     => 'color',
				'title'    => esc_html__('Footer Title Color', 'eduhap'), 
				'subtitle' => esc_html__('Please use color ', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#3f3a64'
			),			

			array(
				'id'       => 'eduhap_footer_text_color',
				'type'     => 'color',
				'title'    => esc_html__('Footer Text Color', 'eduhap'), 
				'subtitle' => esc_html__('Please use color ', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#535967'
			),	
				
			array(
				'id'       => 'eduhap_footer_link_color',
				'type'     => 'color',
				'title'    => esc_html__('Link Color', 'eduhap'), 
				'subtitle' => esc_html__('Please use color ', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#222'
			),				
			
			array(
				'id'       => 'eduhap_footer_link_hover_color',
				'type'     => 'color',
				'title'    => esc_html__('Link Hover Color', 'eduhap'), 
				'subtitle' => esc_html__('Please use color ', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#20ad96'
			),			

			array(
				'id'       => 'eduhap_scroll_up_opt',
				'type'     => 'info',
				'style'     => 'success',
				'title'    => esc_html__('Scroll Color', 'eduhap'), 
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
			),	
			
			array(
				'id'       => 'eduhap_scroll_border_color',
				'type'     => 'color',
				'title'    => esc_html__('Scroll Border Color', 'eduhap'), 
				'subtitle' => esc_html__('Please use color ', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#20ad96'
			),				
			
			array(
				'id'       => 'eduhap_scroll_up_text_color',
				'type'     => 'color',
				'title'    => esc_html__('Scroll up Text Color', 'eduhap'), 
				'subtitle' => esc_html__('Please use color ', 'eduhap'),
				'transparent'     => false,
				'required' => array( 'eduhap_custom_css_opt', '=', '1' ),
				'default'  => '#20ad96'
			),			
        )
    ) );	
	

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Footer Settings', 'eduhap' ),
        'id'               => 'eduhap-foooter-setting',
        'icon'             => 'el el-stop-alt',
        'customizer_width' => '400px',
        'fields'           => array(

            array(
                'id'       => 'eduhap_footer_style',
                'type'     => 'select',
                'title'    => esc_html__('Footer Style', 'eduhap'),
                'subtitle' => esc_html__('Select option here', 'eduhap'),
				'options'  => array(
					'1' => 'One',
					'2' => 'Two',
				),
				'default'  => '1',
            ),            
			
			array(
                'id'       => 'eduhap_footer_logo',
                'type'     => 'media',
                'title'    => esc_html__('Footer Logo', 'eduhap'),
                'subtitle' => esc_html__('Select option here', 'eduhap'),
            ),	
			

			array(
                'id'       => 'eduhap_footer_top_opt',
                'type'     => 'switch',
                'title'    => esc_html__('Footer Top Option', 'eduhap'),
                'subtitle' => esc_html__('Show / hide banner Image', 'eduhap'),
                'default'  => '0'// 1 = on | 0 = off
            ),
						
			array(
                'id'       => 'eduhap_copyright_text',
                'type'             => 'editor',
                'title'            => esc_html__('Copyright Text', 'eduhap'), 
                'subtitle'         => esc_html__('Write Copyright text here.', 'eduhap'),
                'default'          => '© Copyright Eduhap Theme All rights reserved. Crafted by Themesvila',
                'args'   => array(
                    'teeny'            => true,
                    'textarea_rows'    => 4
                )
            ),


			array(
                'id'       => 'eduhap_scroll_switch',
                'type'     => 'switch',
                'title'    => esc_html__('Scroll Up Option', 'eduhap'),
                'subtitle' => esc_html__('Show / hide banner Image', 'eduhap'),
                'default'  => '1'// 1 = on | 0 = off
            ),			
			
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Extra Settings', 'eduhap' ),
        'id'               => 'eduhap-demo-login-setting',
        'customizer_width' => '400px',
        'fields'           => array(

			array(
                'id'       => 'eduhap_demo_login_content',
                'type'             => 'textarea',
                'title'            => esc_html__('Demo Login Content', 'eduhap'), 
				'default'  => '',
                'subtitle'         => esc_html__('enter text here', 'eduhap'),
            ),			
	

        )
    ) );
    /*
     * <--- END SECTIONS
     */


//define

include_once(EDUHAPCOREDIR. '/inc/custom_css.php');