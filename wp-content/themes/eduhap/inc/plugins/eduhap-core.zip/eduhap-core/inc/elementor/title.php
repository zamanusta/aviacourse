<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapTitleWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-title';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Title' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_title_alignment',
			[
				'label' => esc_html__( 'Alignment', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Left', 'eduhap' ),
					'2' => esc_html__( 'Center', 'eduhap' ),
	
				],
				
			]
		);	
	
		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Maximize your potentials',
			]
		);	
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Learn the secrets to Life Success',
			]
		);	
		
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'The ultimate planning solution for
				busy women who want to reach their personal goals',
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_title_alignment = $this->get_settings_for_display( 'sec_title_alignment' );
		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		
		?>

		<div class="section-heading <?php if($sec_title_alignment=='2' ){
				echo esc_attr(' center-heading');
			} ?>">
			<?php if($sec_subtitle){ ?>
			<span class="subheading"><?php echo eduhap_wp_kses($sec_subtitle);?></span>
			<?php } ?>
			<?php if($sec_title){ ?>
			<h3><?php echo eduhap_wp_kses($sec_title);?></h3>
			<?php } ?>
			<?php if($sec_title){ ?>
			<p><?php echo eduhap_wp_kses($sec_content);?></p>
			<?php } ?>
		</div>

<?php

	}

}
