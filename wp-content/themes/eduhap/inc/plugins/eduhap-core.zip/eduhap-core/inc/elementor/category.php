<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapCategoryWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-category';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Course Category' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_category',
			[
				'label' => esc_html__( 'Course Category', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

	
		$this->add_control(
			'category_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Top Categories',
			]
		);		
		
		$this->add_control(
			'category_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Explore by category',
			]
		);	
	
		$this->add_control(
			'category_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'The ultimate planning solution for busy women who want to reach their personal goals',
			]
		);	
		
			
		$this->add_control(
			'btn_text',
			[
				'label' => esc_html__( 'Button Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Explore All',
			]
		);		
		
		$this->add_control(
			'btn_link',
			[
				'label' => esc_html__( 'Button Link', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);	
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$category_subtitle = $this->get_settings_for_display( 'category_subtitle' );
		$category_title = $this->get_settings_for_display( 'category_title' );
		$category_content = $this->get_settings_for_display( 'category_content' );
		$number_posts = $this->get_settings_for_display( 'number_posts' );
		$btn_text = $this->get_settings_for_display( 'btn_text' );
		$btn_link = $this->get_settings_for_display( 'btn_link' );
		global $post, $authordata;
		
		?>
	
    <!--course category section start-->
    <section class="section-padding course-category" >
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-lg-7">
                    <div class="section-heading center-heading">
                        <span class="subheading"><?php echo eduhap_wp_kses($category_subtitle);?></span>
                        <h3><?php echo eduhap_wp_kses($category_title);?></h3>
                        <p><?php echo eduhap_wp_kses($category_content);?></p>
                    </div>
                </div>
            </div>
           
            <div class="row">
			
			<?php
			   $args = array(
				   'taxonomy' => 'course-category',
				   'orderby' => 'name',
				   'order'   => 'ASC',
				   'number' => $number_posts
			   );

			   $course_category = get_categories($args);

			   foreach($course_category as $cat) {
				   
				$image_id = get_term_meta( $cat->term_id, 'thumbnail_id', true );
				$post_thumbnail_img = wp_get_attachment_image_src( $image_id, 'thumbnail' );
			?>
				<div class="col-xl-3 col-lg-3 col-md-6">
					<div class="single-course-category" style="background-image: url(<?php echo esc_url($post_thumbnail_img[0]); ?>);">
					
						<h4>
							<a href="<?php echo get_category_link( $cat->term_id ) ?>">
							<?php echo $cat->name; ?>
						</a>							

						</h4>
						<p><?php echo $cat->count; ?> <?php echo esc_html__('Courses', 'eduhap');?></p>
					</div>
				</div>	
				  
			<?php
			   } ?>
			
            </div>
			<?php if($btn_link){ ?>
            <div class="row">
                <div class="col-xl-12">
                    <div class="text-center mt-5">
                        <a href="<?php echo esc_url($btn_link);?>" class="btn btn-solid-border"><?php echo esc_html($btn_text);?></a>
                    </div>
                </div>
            </div>
			<?php } ?>
        </div>
    </section>
    <!--course section end-->		
		
<?php


	}

}
