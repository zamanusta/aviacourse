<?php 
function eduhap_movers_custom_css(){
	global $eduhap;
	
	if(!is_admin()) :
	?>
  
	<?php 
	
		$eduhap_theme_color_opt						 = '';
		$eduhap_bor_btn_text_color						 = '';
		$eduhap_bor_btn_text_hovercolor						 = '';
		$eduhap_bor_btn_bg_hovercolor						 = '';
		$eduhap_button_bgcolor_opt						 = '';
		$eduhap_button_textcolor_opt						 = '';
		$eduhap_button_hover_textcolor_opt						 = '';
		$eduhap_button_hover_bgcolor_opt						 = '';
		$eduhap_header_top_bgcolor_opt						 = '';
		$eduhap_header_top_text_color_opt						 = '';
		$eduhap_header_top_link_color_opt						 = '';
		$eduhap_header_top_link_hcolor_opt						 = '';
		$eduhap_custom_css_opt						 = '';
		$eduhap_menu_text_color						 = '';
		$eduhap_sticky_menu_bg_color						 = '';
		$eduhap_sticky_menu_text_color						 = '';
		$eduhap_menu_text_hover_color						 = '';
		$eduhap_submenu_border_color						 = '';	
		$eduhap_submenu_bg_color						 = '';	
		$eduhap_submenu_text_color						 = '';	
		$eduhap_submenu_hover_bg_color						 = '';	
		$eduhap_submenu_hover_text_color						 = '';	
		$eduhap_log_btn_text_color						 = '';	
		$eduhap_log_btn_text_hovercolor						 = '';	
		$eduhap_log_btn_bg_hovercolor						 = '';	
		$eduhap_footer_backgorund_color						 = '';
		$eduhap_footer_title_color						 = '';	
		$eduhap_footer_text_color						 = '';	
		$eduhap_footer_link_color						 = '';	
		$eduhap_footer_link_hover_color						 = '';		
		$eduhap_spinner_bgcolor						 = '';
		$eduhap_spinner_color						 = '';	
		$eduhap_spinner_border_color						 = '';	
		$eduhap_scroll_border_color						 = '';		
		$eduhap_scroll_up_text_color						 = '';		
	
		

		if ( isset( $eduhap['eduhap_custom_css_opt'] ) ) {
			$eduhap_custom_css_opt = $eduhap['eduhap_custom_css_opt'];
		}	
	
		if ( isset( $eduhap['eduhap_theme_color_opt'] ) ) {
			$eduhap_theme_color_opt = $eduhap['eduhap_theme_color_opt'];
		}
	
		if ( isset( $eduhap['eduhap_bor_btn_text_color'] ) ) {
			$eduhap_bor_btn_text_color = $eduhap['eduhap_bor_btn_text_color'];
		}			
		if ( isset( $eduhap['eduhap_bor_btn_text_hovercolor'] ) ) {
			$eduhap_bor_btn_text_hovercolor = $eduhap['eduhap_bor_btn_text_hovercolor'];
		}				
		
		if ( isset( $eduhap['eduhap_bor_btn_bg_hovercolor'] ) ) {
			$eduhap_bor_btn_bg_hovercolor = $eduhap['eduhap_bor_btn_bg_hovercolor'];
		}			
		if ( isset( $eduhap['eduhap_button_bgcolor_opt'] ) ) {
			$eduhap_button_bgcolor_opt = $eduhap['eduhap_button_bgcolor_opt'];
		}			
		
		if ( isset( $eduhap['eduhap_button_textcolor_opt'] ) ) {
			$eduhap_button_textcolor_opt = $eduhap['eduhap_button_textcolor_opt'];
		}	

		if ( isset( $eduhap['eduhap_button_hover_textcolor_opt'] ) ) {
			$eduhap_button_hover_textcolor_opt = $eduhap['eduhap_button_hover_textcolor_opt'];
		}	
		
		if ( isset( $eduhap['eduhap_button_hover_bgcolor_opt'] ) ) {
			$eduhap_button_hover_bgcolor_opt = $eduhap['eduhap_button_hover_bgcolor_opt'];
		}	

		if ( isset( $eduhap['eduhap_header_top_bgcolor_opt'] ) ) {
			$eduhap_header_top_bgcolor_opt = $eduhap['eduhap_header_top_bgcolor_opt'];
		}	

		if ( isset( $eduhap['eduhap_header_top_text_color_opt'] ) ) {
			$eduhap_header_top_text_color_opt = $eduhap['eduhap_header_top_text_color_opt'];
		}	
	
		if ( isset( $eduhap['eduhap_header_top_link_color_opt'] ) ) {
			$eduhap_header_top_link_color_opt = $eduhap['eduhap_header_top_link_color_opt'];
		}	
	
		if ( isset( $eduhap['eduhap_header_top_link_hcolor_opt'] ) ) {
			$eduhap_header_top_link_hcolor_opt = $eduhap['eduhap_header_top_link_hcolor_opt'];
		}	
	
		if ( isset( $eduhap['eduhap_menu_text_color'] ) ) {
			$eduhap_menu_text_color = $eduhap['eduhap_menu_text_color'];
		}			
		
		if ( isset( $eduhap['eduhap_sticky_menu_bg_color'] ) ) {
			$eduhap_sticky_menu_bg_color = $eduhap['eduhap_sticky_menu_bg_color'];
		}		
		if ( isset( $eduhap['eduhap_sticky_menu_text_color'] ) ) {
			$eduhap_sticky_menu_text_color = $eduhap['eduhap_sticky_menu_text_color'];
		}		
		if ( isset( $eduhap['eduhap_menu_text_hover_color'] ) ) {
			$eduhap_menu_text_hover_color = $eduhap['eduhap_menu_text_hover_color'];
		}			
	
		if ( isset( $eduhap['eduhap_submenu_border_color'] ) ) {
			$eduhap_submenu_border_color = $eduhap['eduhap_submenu_border_color'];
		}	
		
		if ( isset( $eduhap['eduhap_submenu_bg_color'] ) ) {
			$eduhap_submenu_bg_color = $eduhap['eduhap_submenu_bg_color'];
		}	
							
		if ( isset( $eduhap['eduhap_submenu_text_color'] ) ) {
			$eduhap_submenu_text_color = $eduhap['eduhap_submenu_text_color'];
		}				
			
		if ( isset( $eduhap['eduhap_submenu_hover_text_color'] ) ) {
			$eduhap_submenu_hover_text_color = $eduhap['eduhap_submenu_hover_text_color'];
		}	
		
		if ( isset( $eduhap['eduhap_log_btn_text_color'] ) ) {
			$eduhap_log_btn_text_color = $eduhap['eduhap_log_btn_text_color'];
		}			
		
		if ( isset( $eduhap['eduhap_log_btn_text_hovercolor'] ) ) {
			$eduhap_log_btn_text_hovercolor = $eduhap['eduhap_log_btn_text_hovercolor'];
		}		
		
		if ( isset( $eduhap['eduhap_log_btn_bg_hovercolor'] ) ) {
			$eduhap_log_btn_bg_hovercolor = $eduhap['eduhap_log_btn_bg_hovercolor'];
		}	
		
		if ( isset( $eduhap['eduhap_submenu_hover_bg_color'] ) ) {
			$eduhap_submenu_hover_bg_color = $eduhap['eduhap_submenu_hover_bg_color'];
		}	
		
		if ( isset( $eduhap['eduhap_spinner_bgcolor'] ) ) {
			$eduhap_spinner_bgcolor = $eduhap['eduhap_spinner_bgcolor'];
		}		
		
		if ( isset( $eduhap['eduhap_spinner_border_color'] ) ) {
			$eduhap_spinner_border_color = $eduhap['eduhap_spinner_border_color'];
		}		
		
		if ( isset( $eduhap['eduhap_spinner_color'] ) ) {
			$eduhap_spinner_color = $eduhap['eduhap_spinner_color'];
		}			
		
		if ( isset( $eduhap['eduhap_footer_backgorund_color'] ) ) {
			$eduhap_footer_backgorund_color = $eduhap['eduhap_footer_backgorund_color'];
		}		

		if ( isset( $eduhap['eduhap_footer_title_color'] ) ) {
			$eduhap_footer_title_color = $eduhap['eduhap_footer_title_color'];
		}
		
		if ( isset( $eduhap['eduhap_footer_text_color'] ) ) {
			$eduhap_footer_text_color = $eduhap['eduhap_footer_text_color'];
		}		
		
		if ( isset( $eduhap['eduhap_footer_link_color'] ) ) {
			$eduhap_footer_link_color = $eduhap['eduhap_footer_link_color'];
		}		
		
		if ( isset( $eduhap['eduhap_footer_link_hover_color'] ) ) {
			$eduhap_footer_link_hover_color = $eduhap['eduhap_footer_link_hover_color'];
		}			

		
		if ( isset( $eduhap['eduhap_scroll_border_color'] ) ) {
			$eduhap_scroll_border_color = $eduhap['eduhap_scroll_border_color'];
		}			
		
		if ( isset( $eduhap['eduhap_scroll_up_text_color'] ) ) {
			$eduhap_scroll_up_text_color = $eduhap['eduhap_scroll_up_text_color'];
		}		
		

	
	if($eduhap_custom_css_opt == true){

	wp_enqueue_style( 'eduhap-custom-css', get_template_directory_uri() . '/css/custom-style.css' );
	
	//add custom css
	$eduhap_custom_css = "
	
		body .btn-solid-border{
			color: {$eduhap_bor_btn_text_color};
			border-color: {$eduhap_bor_btn_text_color};
		}
		body .btn-solid-border:hover,
		body .btn-solid-border:focus{
			color: {$eduhap_bor_btn_text_hovercolor};
			background: {$eduhap_bor_btn_bg_hovercolor};
			border-color: {$eduhap_bor_btn_bg_hovercolor};
		}
		body .btn-main{
			background: {$eduhap_button_bgcolor_opt};
			border-color: {$eduhap_button_bgcolor_opt};
			color: {$eduhap_button_textcolor_opt};
		}		
		
		body .btn-main:hover,
		body .btn-main:focus{
			background: {$eduhap_button_hover_bgcolor_opt};
			border-color: {$eduhap_button_hover_bgcolor_opt};
			color: {$eduhap_button_hover_textcolor_opt};
		}
		
		
		body .preloader{
			background: {$eduhap_spinner_bgcolor};
		}
		body .status-mes{
			border-top: 4px solid {$eduhap_spinner_border_color};
			border-right: 4px solid {$eduhap_spinner_border_color};
			border-bottom: 4px solid {$eduhap_spinner_border_color};
			border-left-color: {$eduhap_spinner_color};
		}		

		body .header-top{
			background: {$eduhap_header_top_bgcolor_opt};
			color: {$eduhap_header_top_text_color_opt};
		}	
		body .header-top p{
			color: {$eduhap_header_top_text_color_opt};
		}
		body .header-top p a,
		body .header-top a{
			color: {$eduhap_header_top_link_color_opt};
		}
		
		body .header-top p a:hover,
		body .header-top a:hover,
		body .header-top a:focus
		{
			color: {$eduhap_header_top_link_hcolor_opt};
		}
		
		body #navbarMenu li a
		{
			color: {$eduhap_menu_text_color};
		}
		body #navbarMenu li a:hover,
		body #navbarMenu li a:focus{
			color: {$eduhap_menu_text_hover_color};
		}
		body .menu_fixed{
			background: {$eduhap_sticky_menu_bg_color};
		}
		body .menu_fixed #navbarMenu li a
		{
			color: {$eduhap_sticky_menu_text_color};
		}		
				
		body #navbarMenu .sub-menu {
			background: {$eduhap_submenu_bg_color};
			border-top: 2px solid {$eduhap_submenu_border_color};;
		}	
		body #navbarMenu .sub-menu a {
			color: {$eduhap_submenu_text_color};
		}
		
		body #navbarMenu .sub-menu a:hover{
			background: {$eduhap_submenu_hover_bg_color};
			color: {$eduhap_submenu_hover_text_color};
		}
		body .progress-wrap svg.progress-circle path{
			stroke: {$eduhap_scroll_border_color};
		}
		body .progress-wrap::before{
			background-image: linear-gradient(298deg, {$eduhap_scroll_border_color}, {$eduhap_scroll_border_color});
		}
		body .progress-wrap::after{

			color: {$eduhap_scroll_up_text_color};
		}

		body .footer,
		body .footer-2
		{
			background-color: {$eduhap_footer_backgorund_color};
			color: {$eduhap_footer_text_color};
		}
		
		body .footer .footer-widget .widget-title,
		body .footer-2 .footer-widget .widget-title
		{
			color: {$eduhap_footer_title_color};
		}
		
		body .footer p,
		body .footer-2 p
		{
			color: {$eduhap_footer_text_color};
		}

		body .footer .footer-socials a,
		body .footer_menu_area a,
		body .footer-btm .footer-contact a{
			color: {$eduhap_footer_link_color};
		}		
		
		body .footer_menu_area a:hover,
		body .footer-btm .footer-contact a:hover{
			color: {$eduhap_footer_link_hover_color};
		}

		body .copyright{
			color: {$eduhap_footer_text_color};
		}
			
		
		body a,
		body a:hover,
		body .post-meta .post-author a:hover,
		body .blog-sidebar .widget li a:hover,
		body .blog-sidebar .widget.widget_categories ul li a:hover,
		body .single-post-content .post-meta .blog-comment h3 i,
		body .comments .media .media-body h5 span,
		body .blog-sidebar .widget a:hover, 
		body .blog-sidebar .widget a:focus,
		body .comment-reply-link:hover,
		body .h1 a:hover, 
		body .h2 a:hover, 
		body .h3 a:hover, 
		body .h4 a:hover, 
		body .h5 a:hover, 
		body .h6 a:hover, 
		body h1 a:hover, 
		body h2 a:hover, 
		body h3 a:hover, 
		body h4 a:hover, 
		body h5 a:hover, 
		body h6 a:hover,
		body div.author .author-info ul li a:hover ,
		body .subheading,
		body .feature-icon,
		body .feature-item:hover h4,
		body .counter-item .counter,
		body .about-text-block .icon-box,
		body .testimonial-item .client-info .testionial-author,
		body .course-price,
		body .single-course-category h4 a:hover,
		body .testimonials-slides-2 .testimonial-item i, 
		body .testimonials-slides-3 .testimonial-item i,
		body .course-latest h5
		{
			color: {$eduhap_theme_color_opt};
		}
		body #respond #submit,
		body body .navigation.pagination a:hover, 
		body .navigation.pagination a:focus, 
		body .navigation.pagination .page-numbers.current,
		body .navigation.pagination a:hover, 
		body .navigation.pagination a:focus, 
		body .navigation.pagination .page-numbers.current,
		body .video-icon,
		body .video-icon:hover,
		body .course-img .course-price,
		body .testimonials-slides .owl-dots .owl-dot.active span, 
		body .testimonials-slides .owl-dots .owl-dot:hover span
		{
			background-color: {$eduhap_theme_color_opt};
		}
		body .blog-sidebar .widget .widget-title::before, 
		body .blog-sidebar .widget .wp-block-heading::before,
		body .course-img .course-price2{
			background: {$eduhap_theme_color_opt};
		}
		body .blog-sidebar .widget:hover{
			border-top-color: {$eduhap_theme_color_opt};
		}
		body .posts-navigation a:hover,
		body .posts-navigation a:focus,
		body .wp-block-button__link,
		body .blog-sidebar .widget.widget_search .search-form [type='submit'],
		body .wp-block-tag-cloud a:hover, .wp-block-tag-cloud a:focus, 
		body .blog-sidebar .widget.widget_tag_cloud a:hover,
		body .course-filter li a:hover, 
		body .course-filter li.active a, 
		body .f-link li a:hover, body .f-link li.active a{
			background-color: {$eduhap_theme_color_opt};
			border-color: {$eduhap_theme_color_opt};
		}
		

		body .form-submit #submit, 
		body .entry-content button, 
		body .entry-content input[type='button'], 
		body .entry-content input[type='reset'], 
		body .entry-content input[type='submit'],
		body .form-submit #submit:hover, 
		body .form-submit #submit:focus, 
		body .entry-content button:hover, 
		body .entry-content input[type='button']:hover, 
		body .entry-content input[type='reset']:hover, 
		body .entry-content input[type='submit']:hover,
		body .wp-block-search__button, 
		body .wp-block-search__button:hover, 
		body .wp-block-search__button:focus,
		body div.pagination a, 
		body div.pagination span,
		body .pagination a:hover, 
		body .pagination a:focus, 
		body div.pagination .page-numbers.current,
		body .tagcloud a:hover,
		body .tagcloud a:focus
		{
			background: {$eduhap_theme_color_opt};
			border-color: {$eduhap_theme_color_opt};
		}
		
		body .form-control:focus{
			border-color: {$eduhap_theme_color_opt}!important;
		}
		body blockquote,
		body .posts-navigation a,
		body .slicknav_btn{
			background: {$eduhap_theme_color_opt};
		}
	";
	
	//Add the above custom CSS via wp_add_inline_style
	wp_add_inline_style( 'eduhap-custom-css', $eduhap_custom_css ); //Pass the variable into the main style sheet ID
	}
	
  endif;
}

add_action( 'wp_enqueue_scripts', 'eduhap_movers_custom_css'  ) ;