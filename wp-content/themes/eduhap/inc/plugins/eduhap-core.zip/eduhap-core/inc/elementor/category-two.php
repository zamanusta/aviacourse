<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapCategoryTwoWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-category-two';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Course Category Two' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_category_two',
			[
				'label' => esc_html__( 'Course Category', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

	
		$this->add_control(
			'sec_img',
			[
				'label' => esc_html__( 'Background Image', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,
			]
		);		
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Web Design',
			]
		);	
	
		$this->add_control(
			'sec_details',
			[
				'label' => esc_html__( 'Details', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '2 Courses',
			]
		);	

		$this->add_control(
			'sec_cat_link',
			[
				'label' => esc_html__( 'Category Link', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);	
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_img = $this->get_settings_for_display( 'sec_img' )['url'];
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_details = $this->get_settings_for_display( 'sec_details' );
		$sec_cat_link = $this->get_settings_for_display( 'sec_cat_link' );
		?>
	

		<div class="category-imgbox">
			<div class="thumbnail-img">
				<img src="<?php echo esc_url($sec_img);?>" alt="" class="img-fluid">
			</div>
			<div class="category-content">
				<h5><a href="<?php echo esc_url($sec_cat_link);?>"><?php echo esc_html($sec_title);?></a></h5>
				<p><?php echo esc_html($sec_details);?></p>
			</div>
		</div>
		
<?php


	}

}
