<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapAboutUsWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-about-us';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('About Us' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_about_us',
			[
				'label' => esc_html__( 'About Us', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'sec_icon',
			[
				'label' => esc_html__( 'Icon', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'flaticon-flag',
			]
		);	
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Start from now',
			]
		);	
		
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'The right mentoring relationship can be a powerful tool for professional growth. Bark up the right tree.',
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_icon = $this->get_settings_for_display( 'sec_icon' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		
		?>
		
		<div class="about-text-block">
			<div class="icon-box border-none">
				<i class="<?php echo esc_attr($sec_icon);?>"></i>
			</div>
			<div class="about-desc">
				<h4><?php echo esc_html($sec_title);?></h4>
				<p><?php echo eduhap_wp_kses($sec_content);?></p>
			</div>
		</div>
		
<?php

	}

}
