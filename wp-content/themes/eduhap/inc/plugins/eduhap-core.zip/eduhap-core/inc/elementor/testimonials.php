<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapTestimonialsWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-testimonials';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Testimonials' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_testimonials',
			[
				'label' => esc_html__( 'Testimonials', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_style',
			[
				'label' => esc_html__( 'Style', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::SELECT ,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( '1', 'eduhap' ),
					'2' => esc_html__( '2', 'eduhap' ),
					'3' => esc_html__( '3', 'eduhap' ),
	
				],
				
			]
		);	
		
		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Testimonials',
			]
		);	
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Success Stories from person',
			]
		);	
		
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'The ultimate planning solution for
				busy women who want to reach their personal goals',
			]
		);		
		
		$this->add_control(
			'sec_btn_large_content',
			[
				'label' => esc_html__( 'Button Large Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Help you to get the best course that fits you',
			]
		);			
		
		$this->add_control(
			'sec_btn_text',
			[
				'label' => esc_html__( 'Button Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Free Consultation',
			]
		);			
		
		$this->add_control(
			'sec_btn_link',
			[
				'label' => esc_html__( 'Button Link', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);			
		
		$this->add_control(
			'sec_num',
			[
				'label' => esc_html__( 'Number', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '-1',
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_style = $this->get_settings_for_display( 'sec_style' );
		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		$sec_num = $this->get_settings_for_display( 'sec_num' );
		$sec_btn_large_content = $this->get_settings_for_display( 'sec_btn_large_content' );
		$sec_btn_text = $this->get_settings_for_display( 'sec_btn_text' );
		$sec_btn_link = $this->get_settings_for_display( 'sec_btn_link' );
		
		if($sec_style == '2'){
			
		?>
		
	<!-- Testimonial section start -->
	<section class="testimonial-2 section-padding">
		<div class="container">
			<div class="row align-items-center justify-content-center">
				<div class="col-lg-6 col-xl-5 me-auto">
					<div class="section-heading">
						<span class="subheading"><?php echo esc_html($sec_subtitle);?></span>
						<h3><?php echo eduhap_wp_kses($sec_title);?></h3>
						<p><?php echo eduhap_wp_kses($sec_content);?></p>
					   <p><?php echo eduhap_wp_kses($sec_btn_large_content);?> <a href="<?php echo esc_url($sec_btn_link);?>" class="text-underline d-block"><?php echo esc_html($sec_btn_text);?> <i class="fa fa-angle-right ml-2"></i></a></p>
					</div>
				</div>

		
				<div class="col-lg-6 col-xl-6">
					<div class="testimonials-slides-2 owl-carousel owl-theme">
					
		<?php
							// WP_Query arguments
							$args = array(
								'post_type'              => array( 'testimonials' ),
								'posts_per_page'         => $sec_num,
							);

							// The Query
							$eduhap_testi_query = new WP_Query( $args );

							// The Loop
							if ( $eduhap_testi_query->have_posts() ) {
								while ( $eduhap_testi_query->have_posts() ) {
									$eduhap_testi_query->the_post(); 
									$eduhap_test_designation = get_post_meta(get_the_ID(), '_eduhap_test_designation', true);
									?>

									<div class="testimonial-item">
										<i class="fa fa-quote-right"></i>
										<div class="client-info">
											<?php the_post_thumbnail('eduhap_testi');?>
											<div class="testionial-author"><?php the_title();?></div>
										</div>
										<div class="testimonial-info-title">
											<h4><?php echo esc_html($eduhap_test_designation);?></h4>
										</div>

										<div class="testimonial-info-desc">
											<?php the_content();?>
										</div>
									</div>									
								<?php	
								}
							} else {
								// no posts found
							}

							// Restore original Post Data
							wp_reset_postdata();
							?>
							




					 </div>
				</div>
			</div>
		</div>
	</section>
	<!-- Testimonial section End -->


		<?php }elseif($sec_style == '3'){ ?>
		
<!-- Testimonial section start -->
<section class="testimonial-2 section-padding">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-lg-7 col-xl-7">
                <div class="section-heading center-heading">
					<span class="subheading"><?php echo esc_html($sec_subtitle);?></span>
					<h3><?php echo eduhap_wp_kses($sec_title);?></h3>
					<p><?php echo eduhap_wp_kses($sec_content);?></p>
				</div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12 col-xl-12">
                <div class="testimonials-slides-3 owl-carousel owl-theme">
				
		<?php
							// WP_Query arguments
							$args = array(
								'post_type'              => array( 'testimonials' ),
								'posts_per_page'         => $sec_num,
							);

							// The Query
							$eduhap_testi_query = new WP_Query( $args );

							// The Loop
							if ( $eduhap_testi_query->have_posts() ) {
								while ( $eduhap_testi_query->have_posts() ) {
									$eduhap_testi_query->the_post(); 
									$eduhap_test_designation = get_post_meta(get_the_ID(), '_eduhap_test_designation', true);
									?>

									<div class="testimonial-item testimonial-style-2">
										<i class="fa fa-quote-right"></i>
										
										<div class="testimonial-info-title">
											<h4><?php echo esc_html($eduhap_test_designation);?></h4>
										</div>

										<div class="testimonial-info-desc">
											<?php the_content();?>
										</div>
										
										<div class="client-info">
											<div class="client-img">
												<?php the_post_thumbnail('eduhap_testi');?>
											</div>
											<div class="testionial-author"><?php the_title();?></div>
										</div>
									</div>
					
									
								<?php	
								}
							} else {
								// no posts found
							}

							// Restore original Post Data
							wp_reset_postdata();
							?>					


                 </div>
            </div>
        </div>
    </div>
</section>
<!-- Testimonial section End -->	
		
		<?php }else{ ?>
		
		<!-- Testimonial section start -->
		<section class="testimonial section-padding">
			<div class="container">
				<div class="row align-items-center justify-content-center">
					<div class="col-lg-7">
						<div class="section-heading center-heading">
							<span class="subheading"><?php echo esc_html($sec_subtitle);?></span>
							<h3><?php echo eduhap_wp_kses($sec_title);?></h3>
							<p><?php echo eduhap_wp_kses($sec_content);?></p>
						</div>
					</div>
				</div>
			</div>
			
			<div class="container-fluid px-120">
				<div class="row justify-content-center">
					<div class="col-lg-12">
						<div class="testimonials-slides owl-carousel owl-theme">
							<?php
							// WP_Query arguments
							$args = array(
								'post_type'              => array( 'testimonials' ),
								'posts_per_page'         => $sec_num,
							);

							// The Query
							$eduhap_testi_query = new WP_Query( $args );

							// The Loop
							if ( $eduhap_testi_query->have_posts() ) {
								while ( $eduhap_testi_query->have_posts() ) {
									$eduhap_testi_query->the_post(); 
									$eduhap_test_designation = get_post_meta(get_the_ID(), '_eduhap_test_designation', true);
									?>
									
									<div class="testimonial-item">
										<i class="fa fa-quote-right"></i>
										<div class="client-info">
											<?php the_post_thumbnail('eduhap_testi');?>
											<div class="testionial-author"><?php the_title();?></div>
										</div>
										<div class="testimonial-info-title">
											<h4><?php echo esc_html($eduhap_test_designation);?></h4>
										</div>

										<div class="testimonial-info-desc">
											<?php the_content();?>
										</div>
									</div>
									
								<?php	
								}
							} else {
								// no posts found
							}

							// Restore original Post Data
							wp_reset_postdata();
							?>				

						 </div>
					</div>
				</div>
			</div>
		</section>
		<!-- Testimonial section End -->	
		
		<?php }


	}

}
