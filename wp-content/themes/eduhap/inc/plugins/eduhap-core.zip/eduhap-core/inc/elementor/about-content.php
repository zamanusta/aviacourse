<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapAboutContentWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-about-content';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('About Content' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_about_content',
			[
				'label' => esc_html__( 'About Content', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		
		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Self Development Course ',
			]
		);			
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Get Instant Access To Expert solution',
			]
		);	
		
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'The ultimate planning solution for busy women who want to reach their personal goals.Effortless comfortable eye-catching unique detail ',
			]
		);			

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'ab_clist', [
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);		


		$this->add_control(
			'about_content_list',
			[
				'label' => esc_html__
				( 'Content List', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																															
						'ab_clist' => 'Powerful Audiance',																																																																																																								
																																																										
					],
		
				],

			]
		);	
		
		$this->add_control(
			'sec_btn_text',
			[
				'label' => esc_html__( 'Button Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Our Courses',
			]
		);	
		
		$this->add_control(
			'sec_btn_link',
			[
				'label' => esc_html__( 'Button Link', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '#',
			]
		);	

		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		$about_content_list = $this->get_settings_for_display( 'about_content_list' );
		$sec_btn_text = $this->get_settings_for_display( 'sec_btn_text' );
		$sec_btn_link = $this->get_settings_for_display( 'sec_btn_link' );
		
		?>

		<div class="about-section">
			<div class="section-heading mt-4 mt-lg-0 ">
				<span class="subheading"><?php echo esc_html($sec_subtitle );?></span>
				<h3><?php echo eduhap_wp_kses($sec_title );?></h3>
				<p><?php echo eduhap_wp_kses($sec_content );?></p>
				
			</div>
			<ul class="about-features">
			<?php
				foreach ($about_content_list as $item ) { ?>						
	
				<li>
					<i class="fa fa-check"></i>
					<h5><?php echo eduhap_wp_kses($item['ab_clist']);?></h5>
				</li>
			<?php } ?>

			</ul>

			<a href="<?php echo esc_url($sec_btn_link);?>" class="btn btn-main"><?php echo esc_html($sec_btn_text);?></a>
		</div>

<?php

	}

}
