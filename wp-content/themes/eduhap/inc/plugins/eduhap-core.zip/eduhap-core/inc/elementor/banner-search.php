<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapBannerSearchWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-banner-search';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Banner Search' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_banner_search',
			[
				'label' => esc_html__( 'Banner Search', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'sec_bgimage',
			[
				'label' => esc_html__( 'Background', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::MEDIA ,

			]
		);		

		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => ' Expert instruction ',
			]
		);	
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'It\'s time to amplify your online business',
			]
		);	
		
		$this->add_control(
			'search_text',
			[
				'label' => esc_html__( 'Search Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Search',
			]
		);		

		
		$this->add_control(
			'serch_place_hold',
			[
				'label' => esc_html__( 'Placeholder Image', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'What do you want to learn?',
			]
		);	
		
		$this->add_control(
			'cat_text',
			[
				'label' => esc_html__( 'Category Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'category',
			]
		);		
		
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'cata_text', [
				'label' => esc_html__( 'Text', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);		
		

		$this->add_control(
			'category_list',
			[
				'label' => esc_html__
				( 'Category List', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[																																					
						'cata_text' => 'Wordpress',																																																																																																			
																																																										
					],
		
				],

			]
		);			

		
		$this->end_controls_section();


	}
	
	protected function render(){		

		$sec_bgimage = $this->get_settings_for_display( 'sec_bgimage' )['url'];
		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$search_text = $this->get_settings_for_display( 'search_text' );
		$serch_place_hold = $this->get_settings_for_display( 'serch_place_hold' );
		$cat_text = $this->get_settings_for_display( 'cat_text' );
		$category_list = $this->get_settings_for_display( 'category_list' );

		?>


		<section class="banner-3" style="Background: url(<?php echo esc_url($sec_bgimage);?>);">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-md-12 col-xl-8">
						<div class="banner-content text-center">
							<span class="subheading"><?php echo eduhap_wp_kses($sec_subtitle);?></span>
							<h1><?php echo eduhap_wp_kses($sec_title);?></h1>
								
							<div class="form-banner">
								<form action="<?php echo esc_url(home_url('/'));?>" class="form-search-banner">
									<input type="text" class="form-control" name="s" placeholder="<?php echo esc_attr($serch_place_hold);?>">
									<input type="hidden" name="post_type" value="courses" />
									<button type="submit" class="btn btn-main"><?php echo esc_html($search_text);?> <i class="fa fa-search ml-2"></i> </button>
								</form>
							</div>
							<div class="banner-cat">
								<span><?php echo esc_html($cat_text);?> : </span>
								<?php
									foreach ($category_list as $item ) { ?>	

									<span><?php echo esc_html($item['cata_text']);?></span>						
											
								<?php } ?>									
							

							</div>
						</div>
					</div>
				</div> <!-- / .row -->
			</div> <!-- / .container -->
		</section>

<?php

	}

}
