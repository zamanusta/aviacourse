<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapContactInfoWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-contact-info';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Contact Info' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_contact_info',
			[
				'label' => esc_html__( 'Contact Info', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Email Us',
			]
		);	
		
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'support@email.com',
			]
		);		
		
		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		
		?>

		<div class="contact-item">
			<p><?php echo esc_html($sec_title);?></p>
			<h4><?php echo eduhap_wp_kses($sec_content);?></h4>
		</div>

<?php

	}

}
