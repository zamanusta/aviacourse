<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EduhapCoursesWidget extends \Elementor\Widget_Base{
	
	public function get_name() {
		
		return 'eduhap-courses';
	}
	public function get_icon() {
		
		return 'eicon-shortcode';
	}
	public function get_title() {
		return esc_html__('Courses' , 'eduhap');
	}
	
	public function get_categories() {
		return ['eduhap-category'];
	}
	
	protected function register_controls() {

		$this->start_controls_section(
		'eduhap_courses',
			[
				'label' => esc_html__( 'Courses', 'eduhap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

	
		$this->add_control(
			'sec_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => 'Courses ',
			]
		);		
		
		$this->add_control(
			'sec_title',
			[
				'label' => esc_html__( 'Title', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'Over 200+ Online Courses ',
			]
		);	
	
		$this->add_control(
			'sec_content',
			[
				'label' => esc_html__( 'Content', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA ,
				'default' => 'The ultimate planning solution for busy women who want to reach their personal goals',
			]
		);		
		
		$this->add_control(
			'sec_num_post',
			[
				'label' => esc_html__( 'Number of Post', 'eduhap' ),
				'type' => \Elementor\Controls_Manager::TEXT ,
				'default' => '-1',
			]
		);	

		
		$this->end_controls_section();

	}
	
	protected function render(){		

		$sec_subtitle = $this->get_settings_for_display( 'sec_subtitle' );
		$sec_title = $this->get_settings_for_display( 'sec_title' );
		$sec_content = $this->get_settings_for_display( 'sec_content' );
		$sec_num_post = $this->get_settings_for_display( 'sec_num_post' );

		 ?>
			<section class="section-padding course-grid bg-gray">
				<div class="container">
					<div class="row align-items-center justify-content-center">
						<div class="col-lg-7">
							<div class="section-heading center-heading">
								<span class="subheading"><?php echo esc_html($sec_subtitle);?></span>
								<h3><?php echo eduhap_wp_kses($sec_title);?></h3>
								<p><?php echo eduhap_wp_kses($sec_content);?></p>
							</div>
						</div>
					</div>

				   <div class="text-center">
						<?php $terms = get_terms('course-category');
								if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
							?>
							<ul class="course-filter">
								<li class="active"><a href="#" data-filter="*"> <?php esc_html_e('All' , 'eduhap');?></a></li>
								
								<?php foreach ( $terms as $term ) : ?>		
								<li class=""><a href="#" data-filter=".<?php echo esc_attr($term->slug); ?>"><?php echo esc_html($term->name); ?></a></li>
								<?php endforeach;?>
							</ul>
						<?php } ?>

				   </div>

					<div class="row course-gallery ">

						<?php

						// WP_Query arguments
						$args = array(
							'post_type'              => array( 'courses' ),
							'posts_per_page'         => $sec_num_post,
						);

						// The Query
						$eduhap_course_query = new WP_Query( $args );

						// The Loop
						if ( $eduhap_course_query->have_posts() ) {
							while ( $eduhap_course_query->have_posts() ) {
								$eduhap_course_query->the_post();								

								$portfolio_terms = get_the_terms(get_the_id(), 'course-category');
								
								if ( ! empty( $portfolio_terms ) && ! is_wp_error( $portfolio_terms ) ):
									
									$portfolios_cat_slug = array();
									
									foreach($portfolio_terms as $portfolio_term){
										$portfolios_cat_slug[] = $portfolio_term->slug ;
									}
									
									$portfolios_cat_array = join(" ", $portfolios_cat_slug);
									$portfolios_class_array = join(" ", $portfolios_cat_slug);
								endif;
								
								$course_id         = get_the_ID();
								$course_students   = apply_filters( 'tutor_course_students', tutor_utils()->count_enrolled_users_by_course( $course_id ), $course_id );
								$course_lesson = get_post_meta(get_the_ID(),'_eduhap_course_lesson', true);
								$course_duration = get_tutor_course_duration_context( $course_id, true );							
								?>


								<div class="course-item <?php echo esc_attr($portfolios_class_array);?> col-lg-4 col-md-6">
									<div class="course-block">
										<div class="course-img">
											<?php the_post_thumbnail('eduhap_course');?>
											<div class="course-price2">
												<?php
													$price = tutor_utils()->get_course_price();
												if ( null === $price ) {
													esc_html_e( 'Free', 'tutor' );
												} else {
													echo wp_kses_post( tutor_utils()->get_course_price() );
												}
												?>		
											</div>  
										</div>
										
										<div class="course-content">
											<div class="course-meta">
												<span class="course-student"><i class="fa fa-user-alt"></i> <?php echo esc_html( $course_students ); ?> <?php echo esc_html__('Students' , 'eduhap');?></span>
												<span class="course-duration"><i class="far fa-file-alt"></i> <?php echo esc_html( tutor_utils()->get_lesson_count_by_course( $course_id ) ) ?> <?php echo esc_html__('Lessons' , 'eduhap');?></span>
											</div>
											
											<h4><a href="<?php the_permalink();?>"><?php echo the_title();?></a></h4>
											<p><?php echo eduhap_trip_content(13);?></p>
										</div>
									</div>
								</div>
						
								<?php

							}
						} else {
							// no posts found
						}

						// Restore original Post Data
						wp_reset_postdata();
						
						
					?>			
					

					</div>
				</div>
			</section>		
		<?php ?>



<?php


	}

}
